import React, { useState, useEffect } from 'react';
import { BookOpen, Brain, RotateCcw, Play, CheckCircle, ChevronDown, ChevronUp, Clock, AlertTriangle, Target, Calculator, PenTool, Layout, X, Lock } from 'lucide-react';
import { SAT_MATH_DOMAINS, SAT_READING_DOMAINS, SATDomain, SATSkill } from '../data/satData';
import { generateSATQuestions, generateFullSATExam, generateSATLesson } from '../services/geminiService';
import { QuizQuestion } from '../types';
import { getUserTier } from '../utils/security';

const SATPrep: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'practice' | 'topics' | 'full-exam'>('practice');
  const [isAllowed, setIsAllowed] = useState(true);

  useEffect(() => {
    const tier = getUserTier();
    // Block SAT Prep for 'Initiate' tier entirely
    if (tier === 'Initiate') {
      setIsAllowed(false);
    }
  }, []);

  if (!isAllowed) {
    return (
      <div className="max-w-4xl mx-auto py-20 px-4 text-center animate-enter">
         <div className="w-24 h-24 rounded-full bg-zinc-900 border border-zinc-800 flex items-center justify-center mx-auto mb-8 shadow-2xl">
            <Lock size={40} className="text-zinc-600" />
         </div>
         <h1 className="text-4xl font-bold text-white mb-4">Restricted Protocol</h1>
         <p className="text-zinc-400 max-w-lg mx-auto mb-8">
           The SAT Mastery Engine is reserved for Scholar tier users. 
           Upgrade your clearance level to access adaptive generation and full-length simulations.
         </p>
         <div className="p-6 bg-red-900/10 border border-red-900/30 rounded-2xl max-w-md mx-auto">
            <span className="text-xs font-mono text-red-400 uppercase tracking-widest">Clearance: Initiate (Denied)</span>
         </div>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto py-8 animate-enter px-4">
      {/* Header */}
      <div className="text-center mb-12 space-y-4">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-900/20 border border-indigo-500/30 text-indigo-400 text-xs font-bold uppercase tracking-widest backdrop-blur-sm">
           <Target size={12} /> SAT Protocol
        </div>
        <h1 className="text-5xl font-bold text-white tracking-tight">SAT Mastery Engine</h1>
        <p className="text-zinc-400 max-w-xl mx-auto text-lg">Adaptive generation engine calibrated to Official College Board standards.</p>
      </div>

      {/* Tabs */}
      <div className="flex justify-center gap-4 mb-12">
        <TabButton active={activeTab === 'practice'} onClick={() => setActiveTab('practice')} label="Practice Generators" icon={<Brain size={16} />} />
        <TabButton active={activeTab === 'topics'} onClick={() => setActiveTab('topics')} label="Topics & Skills" icon={<Layout size={16} />} />
        <TabButton active={activeTab === 'full-exam'} onClick={() => setActiveTab('full-exam')} label="Full Practice Test" icon={<Clock size={16} />} />
      </div>

      <div className="min-h-[600px]">
        {activeTab === 'practice' && <PracticeGenerators />}
        {activeTab === 'topics' && <TopicsSection />}
        {activeTab === 'full-exam' && <FullExamInterface />}
      </div>
    </div>
  );
};

const TabButton = ({ active, onClick, label, icon }: any) => (
  <button
    onClick={onClick}
    className={`px-6 py-3 rounded-full font-bold text-sm flex items-center gap-2 transition-all duration-300 border ${
      active 
        ? 'bg-indigo-600 border-indigo-500 text-white shadow-[0_0_20px_rgba(79,70,229,0.4)]' 
        : 'bg-zinc-900 border-zinc-800 text-zinc-500 hover:text-white hover:bg-zinc-800'
    }`}
  >
    {icon} {label}
  </button>
);

// --- 1. Practice Generators ---

const PracticeGenerators = () => {
  return (
    <div className="grid md:grid-cols-2 gap-8">
      <GeneratorCard type="MATH" title="SAT Math" desc="Algebra, Advanced Math, Geometry, Data" icon={<Calculator size={32} />} />
      <GeneratorCard type="READING_WRITING" title="Reading & Writing" desc="Craft, Structure, Standard English Conventions" icon={<PenTool size={32} />} />
    </div>
  );
};

const GeneratorCard = ({ type, title, desc, icon }: { type: 'MATH' | 'READING_WRITING', title: string, desc: string, icon: any }) => {
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [loading, setLoading] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [answers, setAnswers] = useState<{[key: string]: number}>({});

  const generate = async () => {
    setLoading(true);
    setSubmitted(false);
    setAnswers({});
    setQuestions([]);
    try {
      const qs = await generateSATQuestions(25, type);
      setQuestions(qs);
    } catch (e) {
      console.error(e);
      alert("Generation failed. Please try again.");
    } finally {
      setLoading(false);
    }
  };

  const score = questions.reduce((acc, q) => acc + (answers[q.id] === q.correctAnswer ? 1 : 0), 0);

  return (
    <div className="bg-[#0A0A0A] border border-white/5 rounded-3xl p-8 relative overflow-hidden flex flex-col h-full">
      <div className={`absolute top-0 left-0 w-full h-1 bg-gradient-to-r ${type === 'MATH' ? 'from-blue-600 to-cyan-400' : 'from-purple-600 to-pink-400'}`}></div>
      
      {!questions.length && !loading ? (
        <div className="flex-1 flex flex-col items-center justify-center text-center space-y-6 py-12">
          <div className={`w-20 h-20 rounded-2xl flex items-center justify-center ${type === 'MATH' ? 'bg-blue-900/20 text-blue-400' : 'bg-purple-900/20 text-purple-400'}`}>
            {icon}
          </div>
          <div>
            <h3 className="text-2xl font-bold text-white mb-2">{title}</h3>
            <p className="text-zinc-500 max-w-xs mx-auto">{desc}</p>
          </div>
          <button 
            onClick={generate}
            className="px-8 py-4 bg-white text-black font-bold rounded-xl shadow-[0_0_20px_rgba(255,255,255,0.2)] hover:scale-105 transition-transform flex items-center gap-2"
          >
            <Play size={18} fill="currentColor" /> Generate 25 Questions
          </button>
        </div>
      ) : loading ? (
        <div className="flex-1 flex flex-col items-center justify-center space-y-4">
          <div className="w-12 h-12 border-4 border-zinc-800 border-t-white rounded-full animate-spin"></div>
          <p className="text-zinc-500 animate-pulse font-mono text-sm">Synthesizing Official College Board Patterns...</p>
        </div>
      ) : (
        <div className="flex-1 flex flex-col h-[600px]">
          <div className="flex justify-between items-center mb-6 pb-4 border-b border-white/5">
             <h3 className="font-bold text-white">{title} Practice Set</h3>
             <div className="flex gap-2">
                {submitted && (
                   <span className="px-3 py-1 bg-zinc-800 rounded text-xs font-bold text-white">
                      Score: {score}/25
                   </span>
                )}
                <button onClick={generate} className="p-2 hover:bg-zinc-800 rounded text-zinc-400 hover:text-white transition-colors">
                   <RotateCcw size={18} />
                </button>
             </div>
          </div>
          
          <div className="flex-1 overflow-y-auto pr-2 custom-scrollbar space-y-8">
            {questions.map((q, idx) => (
              <div key={q.id} className="p-6 rounded-2xl bg-zinc-900/30 border border-white/5">
                <div className="flex gap-4">
                   <span className="text-zinc-500 font-mono text-sm pt-1">{String(idx+1).padStart(2, '0')}</span>
                   <div className="space-y-4 w-full">
                      <p className="text-white text-lg font-medium leading-relaxed whitespace-pre-wrap font-serif">{q.question}</p>
                      <div className="grid gap-2">
                        {q.options.map((opt, optIdx) => {
                          let style = "bg-black border-zinc-800 text-zinc-400 hover:bg-zinc-800";
                          if (submitted) {
                            if (optIdx === q.correctAnswer) style = "bg-green-900/20 border-green-500/50 text-green-400";
                            else if (answers[q.id] === optIdx) style = "bg-red-900/20 border-red-500/50 text-red-400";
                            else style = "bg-black border-zinc-800 text-zinc-600 opacity-50";
                          } else if (answers[q.id] === optIdx) {
                             style = "bg-indigo-600 border-indigo-500 text-white";
                          }

                          return (
                            <button 
                              key={optIdx}
                              onClick={() => !submitted && setAnswers(prev => ({...prev, [q.id]: optIdx}))}
                              className={`w-full text-left p-4 rounded-xl border transition-all ${style}`}
                              disabled={submitted}
                            >
                              <span className="font-mono text-xs mr-3 opacity-50">{String.fromCharCode(65 + optIdx)}</span>
                              {opt}
                            </button>
                          )
                        })}
                      </div>
                      {submitted && (
                        <div className="mt-4 p-4 bg-zinc-800/50 rounded-xl border-l-2 border-green-500 text-sm text-zinc-300">
                          <span className="font-bold text-green-400 block mb-1">Explanation:</span>
                          {q.explanation}
                        </div>
                      )}
                   </div>
                </div>
              </div>
            ))}
          </div>

          {!submitted && (
             <button 
               onClick={() => setSubmitted(true)}
               disabled={Object.keys(answers).length < questions.length}
               className="mt-6 w-full py-4 bg-white text-black font-bold rounded-xl hover:bg-zinc-200 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
             >
               Submit & Reveal Answers
             </button>
          )}
        </div>
      )}
    </div>
  );
};

// --- 2. Topics & Skills ---

const TopicsSection = () => {
  return (
    <div className="space-y-12">
      <TopicGroup title="SAT Math Domains" domains={SAT_MATH_DOMAINS} color="blue" type="MATH" />
      <TopicGroup title="Reading & Writing Domains" domains={SAT_READING_DOMAINS} color="purple" type="READING_WRITING" />
    </div>
  );
};

const TopicGroup: React.FC<{ title: string, domains: SATDomain[], color: string, type: 'MATH' | 'READING_WRITING' }> = ({ title, domains, color, type }) => (
  <div className="space-y-4">
    <h2 className="text-2xl font-bold text-white pl-2 border-l-4 border-zinc-700">{title}</h2>
    <div className="grid gap-4">
       {domains.map(domain => <DomainCard key={domain.id} domain={domain} color={color} type={type} />)}
    </div>
  </div>
);

const DomainCard: React.FC<{ domain: SATDomain, color: string, type: 'MATH' | 'READING_WRITING' }> = ({ domain, color, type }) => {
  const [expanded, setExpanded] = useState(false);
  const bg = color === 'blue' ? 'group-hover:border-blue-500/30' : 'group-hover:border-purple-500/30';

  return (
    <div className={`rounded-2xl bg-[#0A0A0A] border border-white/5 transition-all duration-300 overflow-hidden ${expanded ? 'bg-zinc-900/20 border-white/10' : 'hover:bg-zinc-900/30'} ${bg} group`}>
       <button 
         onClick={() => setExpanded(!expanded)}
         className="w-full flex items-center justify-between p-6 text-left"
       >
         <div>
            <h3 className="text-xl font-bold text-white group-hover:text-white transition-colors">{domain.title}</h3>
            <p className="text-zinc-500 text-sm mt-1">{domain.description}</p>
         </div>
         <div className={`p-2 rounded-full bg-zinc-900 transition-transform duration-300 ${expanded ? 'rotate-180' : ''}`}>
            <ChevronDown size={20} className="text-zinc-400" />
         </div>
       </button>
       
       {expanded && (
         <div className="px-6 pb-6 pt-0 space-y-4 border-t border-white/5">
            <div className="h-4"></div>
            {domain.skills.map((skill, idx) => (
               <SkillItem key={idx} skill={skill} type={type} />
            ))}
         </div>
       )}
    </div>
  );
};

const SkillItem: React.FC<{ skill: SATSkill, type: 'MATH' | 'READING_WRITING' }> = ({ skill, type }) => {
  const [quizOpen, setQuizOpen] = useState(false);
  const [questions, setQuestions] = useState<QuizQuestion[]>([]);
  const [lesson, setLesson] = useState<string>("");
  const [loading, setLoading] = useState(false);
  const [activeModalTab, setActiveModalTab] = useState<'study' | 'quiz'>('study');
  
  // Quiz State
  const [currentQIndex, setCurrentQIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [showResult, setShowResult] = useState(false);

  const startLesson = async () => {
    setLoading(true);
    setQuizOpen(true);
    setQuestions([]);
    setLesson("");
    try {
      // Parallel execution for speed
      const [lessonText, qs] = await Promise.all([
        generateSATLesson(skill.promptContext),
        generateSATQuestions(5, type, skill.promptContext)
      ]);
      setLesson(lessonText);
      setQuestions(qs);
    } catch (e) {
      alert("Failed to load skill module.");
      setQuizOpen(false);
    } finally {
      setLoading(false);
    }
  };

  const handleAnswer = (idx: number) => {
    if (idx === questions[currentQIndex].correctAnswer) setScore(score + 1);
    
    if (currentQIndex < questions.length - 1) {
      setCurrentQIndex(currentQIndex + 1);
    } else {
      setShowResult(true);
    }
  };

  const reset = () => {
    setQuizOpen(false);
    setQuestions([]);
    setLesson("");
    setCurrentQIndex(0);
    setScore(0);
    setShowResult(false);
    setActiveModalTab('study');
  }

  // Styling for injected HTML content
  const styledLesson = lesson
    .replace(/<h2>/g, '<h2 class="text-2xl font-bold text-white mt-8 mb-4 border-b border-white/10 pb-2 flex items-center gap-3"><span class="w-1 h-6 bg-indigo-500 rounded-full"></span>')
    .replace(/<\/h2>/g, '</h2>')
    .replace(/<p>/g, '<p class="text-zinc-300 leading-relaxed mb-6 text-base">')
    .replace(/<ul>/g, '<ul class="space-y-3 mb-8 text-zinc-300 bg-zinc-900/30 p-6 rounded-xl border border-white/5">')
    .replace(/<li>/g, '<li class="flex items-start gap-3"><span class="mt-2 w-1.5 h-1.5 rounded-full bg-indigo-500 flex-shrink-0"></span><span>')
    .replace(/<\/li>/g, '</span></li>')
    .replace(/<strong>/g, '<strong class="text-indigo-300 font-semibold">');

  return (
     <div className="p-5 rounded-xl bg-black border border-white/5 hover:border-white/10 transition-all">
        <div className="flex justify-between items-center mb-1">
           <div>
              <h4 className="font-bold text-white">{skill.title}</h4>
              <p className="text-sm text-zinc-400 mt-1">{skill.description}</p>
           </div>
           <button 
             onClick={startLesson}
             className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded-lg transition-colors flex items-center gap-2 whitespace-nowrap ml-4"
           >
             <Brain size={12} /> Check Understanding
           </button>
        </div>
        
        {/* Lesson & Quiz Modal Overlay */}
        {quizOpen && (
           <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-md p-4 animate-in fade-in">
              <div className="w-full max-w-5xl bg-[#0A0A0A] border border-white/10 rounded-3xl relative shadow-2xl flex flex-col h-[85vh] max-h-[85vh] overflow-hidden">
                 
                 {/* Header & Tabs */}
                 <div className="flex flex-col border-b border-white/5 bg-[#0A0A0A] shrink-0">
                    <div className="flex justify-between items-center p-6 pb-2">
                        <h3 className="text-xl font-bold text-white flex items-center gap-3">
                           <Target size={20} className="text-indigo-500" />
                           {skill.title}
                        </h3>
                        <button onClick={reset} className="p-2 rounded-full hover:bg-white/10 text-zinc-500 hover:text-white transition-colors">
                           <X size={20} />
                        </button>
                    </div>
                    
                    {/* Tab Navigation */}
                    <div className="flex px-6 gap-6">
                        <button 
                           onClick={() => setActiveModalTab('study')}
                           className={`pb-4 text-sm font-bold border-b-2 transition-all ${
                               activeModalTab === 'study' 
                               ? 'text-white border-indigo-500' 
                               : 'text-zinc-500 border-transparent hover:text-zinc-300'
                           }`}
                        >
                           <span className="flex items-center gap-2"><BookOpen size={16} /> Study Guide</span>
                        </button>
                        <button 
                           onClick={() => setActiveModalTab('quiz')}
                           className={`pb-4 text-sm font-bold border-b-2 transition-all ${
                               activeModalTab === 'quiz' 
                               ? 'text-white border-indigo-500' 
                               : 'text-zinc-500 border-transparent hover:text-zinc-300'
                           }`}
                        >
                           <span className="flex items-center gap-2"><CheckCircle size={16} /> Skill Check</span>
                        </button>
                    </div>
                 </div>

                 {/* Content Body */}
                 <div className="flex-1 overflow-hidden relative bg-[#050505]">
                    {loading ? (
                       <div className="h-full flex flex-col items-center justify-center space-y-4">
                          <div className="w-12 h-12 border-4 border-indigo-500 border-t-transparent rounded-full animate-spin"></div>
                          <p className="text-zinc-400 animate-pulse font-mono text-sm">Synthesizing Lesson & Quiz...</p>
                       </div>
                    ) : (
                       <div className="h-full overflow-y-auto custom-scrollbar p-8">
                          
                          {/* Study Guide Tab */}
                          {activeModalTab === 'study' && (
                             <div className="max-w-3xl mx-auto animate-in fade-in slide-in-from-bottom-2 duration-300">
                                <div dangerouslySetInnerHTML={{ __html: styledLesson }} />
                                <div className="mt-12 flex justify-center">
                                   <button 
                                     onClick={() => setActiveModalTab('quiz')}
                                     className="px-8 py-3 bg-white text-black font-bold rounded-full hover:scale-105 transition-transform shadow-lg flex items-center gap-2"
                                   >
                                      Start Practice Quiz <ChevronDown className="rotate-[-90deg]" size={16} />
                                   </button>
                                </div>
                             </div>
                          )}

                          {/* Quiz Tab */}
                          {activeModalTab === 'quiz' && (
                             <div className="max-w-2xl mx-auto h-full flex flex-col justify-center animate-in fade-in slide-in-from-bottom-2 duration-300">
                                {showResult ? (
                                   <div className="text-center space-y-8 bg-zinc-900/30 p-12 rounded-3xl border border-white/5">
                                      <div className="inline-flex p-6 bg-indigo-500/10 rounded-full text-indigo-400 mb-2">
                                         <CheckCircle size={48} />
                                      </div>
                                      <div>
                                         <h4 className="text-4xl font-bold text-white mb-2">{Math.round((score/5)*100)}% Mastery</h4>
                                         <p className="text-zinc-400">You answered {score} out of 5 questions correctly.</p>
                                      </div>
                                      <button onClick={reset} className="px-10 py-4 bg-white text-black font-bold rounded-xl hover:scale-105 transition-transform">
                                         Complete Module
                                      </button>
                                   </div>
                                ) : (
                                   <div className="w-full">
                                      <div className="flex justify-between items-center mb-8">
                                         <span className="text-xs font-mono text-indigo-400 bg-indigo-900/20 px-3 py-1 rounded border border-indigo-500/30">
                                            QUESTION {currentQIndex + 1} / 5
                                         </span>
                                         <span className="text-zinc-600 text-xs font-mono uppercase">Single Selection</span>
                                      </div>
                                      
                                      <p className="text-white text-xl font-medium mb-10 font-serif leading-relaxed whitespace-pre-wrap">
                                        {questions[currentQIndex]?.question}
                                      </p>
                                      
                                      <div className="space-y-3">
                                         {questions[currentQIndex]?.options.map((opt, i) => (
                                            <button 
                                              key={i}
                                              onClick={() => handleAnswer(i)}
                                              className="w-full text-left p-5 rounded-xl bg-[#0A0A0A] border border-zinc-800 hover:bg-zinc-900 hover:border-zinc-600 transition-all text-zinc-300 hover:text-white flex items-center gap-5 group"
                                            >
                                              <div className="w-8 h-8 rounded-full border border-zinc-700 flex items-center justify-center text-sm text-zinc-500 group-hover:border-white group-hover:text-white transition-colors flex-shrink-0">
                                                 {String.fromCharCode(65 + i)}
                                              </div>
                                              <span className="text-base">{opt}</span>
                                            </button>
                                         ))}
                                      </div>
                                   </div>
                                )}
                             </div>
                          )}

                       </div>
                    )}
                 </div>

              </div>
           </div>
        )}
     </div>
  );
};

// --- 3. Full Exam ---

const FullExamInterface = () => {
  const [status, setStatus] = useState<'idle' | 'loading' | 'active' | 'review'>('idle');
  const [section, setSection] = useState<'RW' | 'MATH'>('RW');
  const [timeRemaining, setTimeRemaining] = useState(32 * 60); // 32 mins for R&W Module 1
  const [questions, setQuestions] = useState<{math: QuizQuestion[], rw: QuizQuestion[]} | null>(null);
  const [answers, setAnswers] = useState<{[key: string]: number}>({});
  const [isPaused, setIsPaused] = useState(false);

  // Timer
  useEffect(() => {
    let interval: any;
    if (status === 'active' && !isPaused && timeRemaining > 0) {
      interval = setInterval(() => setTimeRemaining(t => t - 1), 1000);
    } else if (timeRemaining === 0 && status === 'active') {
      if (section === 'RW') {
         // Auto advance to math
         alert("Time's up for Reading & Writing. Starting Math Section.");
         setSection('MATH');
         setTimeRemaining(35 * 60);
      } else {
         finishExam();
      }
    }
    return () => clearInterval(interval);
  }, [status, isPaused, timeRemaining, section]);

  const startExam = async () => {
    setStatus('loading');
    try {
      const data = await generateFullSATExam();
      setQuestions(data);
      setStatus('active');
      setSection('RW');
      setTimeRemaining(32 * 60);
      setAnswers({});
      setIsPaused(false);
    } catch (e) {
      alert("Failed to generate full exam. Try again.");
      setStatus('idle');
    }
  };

  const finishExam = () => {
    setStatus('review');
  };

  const formatTime = (s: number) => {
    const mins = Math.floor(s / 60);
    const secs = s % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  if (status === 'idle') {
    return (
      <div className="rounded-3xl bg-[#0A0A0A] border border-white/5 p-12 text-center relative overflow-hidden group">
         <div className="absolute inset-0 bg-gradient-to-br from-indigo-900/20 to-transparent opacity-50 group-hover:opacity-70 transition-opacity"></div>
         <div className="relative z-10 space-y-6">
            <div className="w-24 h-24 mx-auto rounded-full bg-indigo-900/20 flex items-center justify-center text-indigo-400 border border-indigo-500/30 shadow-[0_0_30px_rgba(79,70,229,0.2)]">
               <Clock size={40} />
            </div>
            <div>
               <h2 className="text-3xl font-bold text-white mb-2">Full-Length SAT Simulation</h2>
               <p className="text-zinc-400 max-w-md mx-auto">Official timing. Adaptive modules. Comprehensive analysis. <br/> This generates a fresh, unique exam every time.</p>
            </div>
            <div className="flex justify-center gap-8 text-sm font-mono text-zinc-500 py-4">
               <span>2 MODULES READING/WRITING (64 MIN)</span>
               <span>|</span>
               <span>2 MODULES MATH (70 MIN)</span>
            </div>
            <button 
              onClick={startExam}
              className="px-10 py-5 bg-white text-black font-bold rounded-full text-lg hover:scale-105 transition-transform shadow-xl"
            >
              Begin Examination
            </button>
         </div>
      </div>
    );
  }

  if (status === 'loading') {
    return (
      <div className="h-[500px] flex flex-col items-center justify-center space-y-6 bg-[#0A0A0A] rounded-3xl border border-white/5">
         <div className="relative">
            <div className="w-24 h-24 border-t-4 border-indigo-500 border-4 border-transparent rounded-full animate-spin"></div>
            <Brain className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 text-zinc-600" />
         </div>
         <div className="text-center space-y-2">
            <h3 className="text-xl font-bold text-white">Compiling Secure Exam Protocol...</h3>
            <p className="text-zinc-500 font-mono">Synthesizing 50+ unique questions across 4 domains</p>
         </div>
      </div>
    );
  }

  if (status === 'review') {
     // Calculate Score
     const totalQ = (questions?.rw.length || 0) + (questions?.math.length || 0);
     const correct = Object.keys(answers).reduce((acc, key) => {
        const q = [...(questions?.rw || []), ...(questions?.math || [])].find(x => x.id === key);
        return acc + (q && answers[key] === q.correctAnswer ? 1 : 0);
     }, 0);
     
     // Rough SAT Score Calc (Very approx)
     const estimatedScore = 400 + Math.round((correct / totalQ) * 1200);

     return (
       <div className="bg-[#0A0A0A] border border-white/5 rounded-3xl p-8">
          <div className="text-center mb-12">
             <div className="text-zinc-500 text-sm font-mono uppercase tracking-widest mb-2">Estimated SAT Score</div>
             <div className="text-8xl font-black text-white tracking-tighter">{estimatedScore}</div>
             <div className="text-zinc-400 mt-4">Raw Score: {correct} / {totalQ}</div>
          </div>
          
          <div className="space-y-8">
             <h3 className="text-xl font-bold text-white border-b border-white/10 pb-4">Performance Breakdown</h3>
             <div className="grid md:grid-cols-2 gap-8">
                <div>
                   <h4 className="font-bold text-purple-400 mb-4">Reading & Writing</h4>
                   <div className="space-y-4">
                      {questions?.rw.map((q, i) => (
                         <div key={q.id} className={`p-4 rounded-xl border ${answers[q.id] === q.correctAnswer ? 'border-green-500/30 bg-green-900/10' : 'border-red-500/30 bg-red-900/10'}`}>
                            <div className="flex justify-between text-xs font-mono mb-2 opacity-70">
                               <span>Q{i+1}</span>
                               <span>{answers[q.id] === q.correctAnswer ? 'CORRECT' : 'INCORRECT'}</span>
                            </div>
                            <p className="text-sm text-zinc-300 mb-2 whitespace-pre-wrap font-serif">{q.question.substring(0, 150)}...</p>
                            <div className="text-xs text-zinc-400 mt-2 p-2 bg-black/30 rounded">
                               <span className="font-bold">Explanation:</span> {q.explanation}
                            </div>
                         </div>
                      ))}
                   </div>
                </div>
                <div>
                   <h4 className="font-bold text-blue-400 mb-4">Math</h4>
                   <div className="space-y-4">
                      {questions?.math.map((q, i) => (
                         <div key={q.id} className={`p-4 rounded-xl border ${answers[q.id] === q.correctAnswer ? 'border-green-500/30 bg-green-900/10' : 'border-red-500/30 bg-red-900/10'}`}>
                            <div className="flex justify-between text-xs font-mono mb-2 opacity-70">
                               <span>Q{i+1}</span>
                               <span>{answers[q.id] === q.correctAnswer ? 'CORRECT' : 'INCORRECT'}</span>
                            </div>
                            <p className="text-sm text-zinc-300 mb-2">{q.question.substring(0, 100)}...</p>
                            <div className="text-xs text-zinc-400 mt-2 p-2 bg-black/30 rounded">
                               <span className="font-bold">Explanation:</span> {q.explanation}
                            </div>
                         </div>
                      ))}
                   </div>
                </div>
             </div>
          </div>
          <div className="mt-12 text-center">
             <button onClick={() => setStatus('idle')} className="px-8 py-3 bg-white text-black font-bold rounded-xl">Close Review</button>
          </div>
       </div>
     )
  }

  // Active Exam
  const currentQs = section === 'RW' ? questions?.rw : questions?.math;

  return (
    <div className="fixed inset-0 z-50 bg-[#000] flex flex-col">
       {/* Exam Header */}
       <div className="h-16 border-b border-white/10 flex items-center justify-between px-8 bg-[#050505]">
          <div className="font-bold text-white flex items-center gap-4">
             <span className="text-xl">SAT Practice Exam 1</span>
             <span className={`px-3 py-1 rounded text-xs font-bold ${section === 'RW' ? 'bg-purple-900/30 text-purple-400' : 'bg-blue-900/30 text-blue-400'}`}>
                SECTION: {section === 'RW' ? 'READING & WRITING' : 'MATH'}
             </span>
          </div>
          
          <div className="flex items-center gap-6">
             <div className="font-mono text-xl font-bold text-white w-24 text-center">
                {formatTime(timeRemaining)}
             </div>
             <button 
               onClick={() => setIsPaused(!isPaused)} 
               className="px-4 py-1.5 rounded bg-zinc-800 text-zinc-300 text-sm font-bold hover:bg-zinc-700"
             >
                {isPaused ? 'Resume' : 'Pause'}
             </button>
             <button 
               onClick={finishExam}
               className="text-xs font-bold text-red-400 hover:text-red-300"
             >
               END EXAM
             </button>
          </div>
       </div>

       {/* Content */}
       <div className={`flex-1 overflow-y-auto p-8 max-w-5xl mx-auto w-full ${isPaused ? 'blur-md pointer-events-none opacity-50' : ''}`}>
          <div className="space-y-12 pb-20">
             {currentQs?.map((q, idx) => (
                <div key={q.id} className="bg-[#0A0A0A] border border-white/10 p-8 rounded-2xl">
                   <div className="flex gap-6">
                      <div className="w-8 h-8 rounded-full bg-zinc-800 flex items-center justify-center text-sm font-bold text-zinc-400 shrink-0">
                         {idx + 1}
                      </div>
                      <div className="space-y-6 flex-1">
                         <p className="text-lg text-white font-medium leading-relaxed whitespace-pre-wrap font-serif">
                            {q.question}
                         </p>
                         <div className="grid gap-3">
                            {q.options.map((opt, optIdx) => (
                               <button 
                                 key={optIdx}
                                 onClick={() => setAnswers(prev => ({...prev, [q.id]: optIdx}))}
                                 className={`w-full text-left p-4 rounded-xl border transition-all flex items-center gap-4 ${
                                    answers[q.id] === optIdx 
                                       ? 'bg-zinc-800 border-white text-white' 
                                       : 'bg-transparent border-zinc-800 text-zinc-400 hover:bg-zinc-900'
                                 }`}
                               >
                                  <div className={`w-6 h-6 rounded-full border flex items-center justify-center text-xs ${answers[q.id] === optIdx ? 'bg-white text-black border-white' : 'border-zinc-600'}`}>
                                     {String.fromCharCode(65 + optIdx)}
                                  </div>
                                  {opt}
                               </button>
                            ))}
                         </div>
                      </div>
                   </div>
                </div>
             ))}
          </div>
       </div>
       
       {/* Footer Nav */}
       <div className="h-20 border-t border-white/10 bg-[#050505] flex items-center justify-between px-8">
          <div className="text-zinc-500 text-sm">{Object.keys(answers).length} questions answered</div>
          {section === 'RW' ? (
             <button onClick={() => { setSection('MATH'); setTimeRemaining(35*60); }} className="px-8 py-3 bg-white text-black font-bold rounded-full">
                Next Section: Math
             </button>
          ) : (
             <button onClick={finishExam} className="px-8 py-3 bg-indigo-600 text-white font-bold rounded-full hover:bg-indigo-500">
                Submit Final
             </button>
          )}
       </div>

       {isPaused && (
          <div className="absolute inset-0 z-50 flex items-center justify-center">
             <div className="text-center">
                <h2 className="text-4xl font-bold text-white mb-4">Exam Paused</h2>
                <button onClick={() => setIsPaused(false)} className="px-8 py-3 bg-white text-black font-bold rounded-full">Resume</button>
             </div>
          </div>
       )}
    </div>
  );
};

export default SATPrep;