
import React, { useState } from 'react';
import { Sparkles, ArrowRight, RotateCcw, CheckSquare, Plus, Edit2, Check } from 'lucide-react';
import { StudyTask } from '../types';
import { generateStudyPlan } from '../services/geminiService';

interface StrategicPlannerProps {
  onAddToDashboard?: (text: string) => void;
}

const StrategicPlanner: React.FC<StrategicPlannerProps> = ({ onAddToDashboard }) => {
  const [goal, setGoal] = useState('');
  const [tasks, setTasks] = useState<StudyTask[]>([]);
  const [loading, setLoading] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editText, setEditText] = useState('');

  const handleGenerate = async () => {
    if (!goal.trim()) return;
    setLoading(true);
    const plan = await generateStudyPlan(goal);
    setTasks(plan.map((t, i) => ({ id: `t-${Date.now()}-${i}`, text: t, completed: false })));
    setLoading(false);
    setGoal('');
  };

  const toggleTask = (id: string) => {
    if (editingId === id) return;
    setTasks(tasks.map(t => t.id === id ? { ...t, completed: !t.completed } : t));
  };

  const startEditing = (task: StudyTask, e: React.MouseEvent) => {
    e.stopPropagation();
    setEditingId(task.id);
    setEditText(task.text);
  };

  const saveEdit = (id: string, e?: React.MouseEvent) => {
    e?.stopPropagation();
    if (!editText.trim()) return;
    setTasks(tasks.map(t => t.id === id ? { ...t, text: editText } : t));
    setEditingId(null);
  };

  const handleEditKeyDown = (e: React.KeyboardEvent, id: string) => {
      if (e.key === 'Enter') {
          saveEdit(id);
      }
      if (e.key === 'Escape') {
          setEditingId(null);
      }
  }

  const handleAddToDashboard = (taskText: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (onAddToDashboard) {
      onAddToDashboard(taskText);
      // Visual feedback handled by App state, button is simple trigger here
    }
  };

  return (
    <div className="max-w-4xl mx-auto py-10 animate-enter">
      <div className="text-center mb-12">
        <h2 className="text-4xl font-bold text-white mb-3">Strategic Planner</h2>
        <p className="text-zinc-500">Define your objective. Let the Neural Engine construct the protocol.</p>
      </div>

      {/* Input Section */}
      <div className="relative max-w-2xl mx-auto mb-16">
        <div className="absolute -inset-0.5 bg-gradient-to-r from-purple-600 to-primary-600 rounded-2xl opacity-30 blur-lg"></div>
        <div className="relative flex items-center bg-[#0A0A0A] rounded-2xl border border-white/10 p-2 shadow-2xl">
          <Sparkles className="ml-4 text-purple-400 animate-pulse" size={20} />
          <input 
            value={goal}
            onChange={(e) => setGoal(e.target.value)}
            placeholder="What do you want to master today?" 
            className="flex-1 bg-transparent px-4 py-4 text-lg text-white outline-none placeholder:text-zinc-600"
            onKeyDown={(e) => e.key === 'Enter' && handleGenerate()}
          />
          <button 
            onClick={handleGenerate}
            disabled={loading || !goal.trim()}
            className="px-6 py-3 bg-white text-black font-bold rounded-xl hover:scale-105 active:scale-95 transition-all disabled:opacity-50 disabled:scale-100 flex items-center gap-2"
          >
            {loading ? 'Generating...' : <>Plan <ArrowRight size={16} /></>}
          </button>
        </div>
      </div>

      {/* Tasks List */}
      <div className="space-y-4">
        {tasks.length > 0 && (
          <div className="flex items-center justify-between px-2 mb-6 text-xs font-bold text-zinc-500 uppercase tracking-widest border-b border-zinc-900 pb-4">
            <span>Execution Protocol</span>
            <button onClick={() => setTasks([])} className="hover:text-red-400 transition-colors flex items-center gap-2">
              <RotateCcw size={12} /> Reset
            </button>
          </div>
        )}

        {tasks.map((task, i) => (
          <div 
            key={task.id} 
            onClick={() => toggleTask(task.id)} 
            className={`group flex items-center gap-5 p-6 rounded-2xl border transition-all duration-300 cursor-pointer animate-enter relative ${
              task.completed 
                ? 'bg-zinc-900/30 border-zinc-900 opacity-50' 
                : editingId === task.id ? 'bg-zinc-900 border-primary-500/50' : 'bg-black border-zinc-800 hover:border-primary-500/30 hover:bg-zinc-900/50'
            }`}
            style={{ animationDelay: `${i * 50}ms` }}
          >
             <div className={`w-8 h-8 rounded-full border-2 flex items-center justify-center transition-all duration-300 flex-shrink-0 ${
               task.completed ? 'bg-green-500 border-green-500' : 'border-zinc-700 group-hover:border-primary-500'
             }`}>
               {task.completed && <CheckSquare size={16} className="text-black" />}
             </div>
             
             {editingId === task.id ? (
                 <input 
                    value={editText}
                    onChange={(e) => setEditText(e.target.value)}
                    onClick={(e) => e.stopPropagation()}
                    onKeyDown={(e) => handleEditKeyDown(e, task.id)}
                    className="flex-1 bg-transparent text-xl font-light text-white outline-none border-b border-primary-500/50 pb-1"
                    autoFocus
                 />
             ) : (
                 <span className={`text-xl font-light flex-1 ${task.completed ? 'text-zinc-600 line-through' : 'text-zinc-200'}`}>
                    {task.text}
                 </span>
             )}

             <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                {/* Add to Dashboard Button */}
                {onAddToDashboard && !task.completed && (
                  <button 
                    onClick={(e) => handleAddToDashboard(task.text, e)}
                    className="p-2 hover:bg-primary-900/30 rounded-lg text-zinc-500 hover:text-primary-400 transition-colors flex items-center gap-1"
                    title="Add to Command Center"
                  >
                    <Plus size={16} />
                  </button>
                )}

                {editingId === task.id ? (
                    <button 
                        onClick={(e) => saveEdit(task.id, e)}
                        className="p-2 bg-primary-600 rounded-lg text-white hover:bg-primary-500"
                    >
                        <Check size={16} />
                    </button>
                ) : (
                    <button 
                        onClick={(e) => startEditing(task, e)}
                        className="p-2 hover:bg-white/10 rounded-lg text-zinc-500 hover:text-white transition-colors"
                        disabled={task.completed}
                    >
                        <Edit2 size={16} />
                    </button>
                )}
             </div>
          </div>
        ))}
        
        {tasks.length === 0 && !loading && (
           <div className="text-center py-20 border border-dashed border-zinc-900 rounded-3xl">
              <div className="w-16 h-16 rounded-full bg-zinc-900/50 flex items-center justify-center mx-auto mb-4 text-zinc-700">
                <Plus size={24} />
              </div>
              <p className="text-zinc-600">No active plan. Initialize one above.</p>
           </div>
        )}
      </div>
    </div>
  );
};

export default StrategicPlanner;
