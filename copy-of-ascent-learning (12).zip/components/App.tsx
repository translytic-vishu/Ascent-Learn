
import React, { useState, useEffect } from 'react';
import { Layout, Menu, FileText, Settings, Plus, Home, Moon, Sun, Search, LogOut, Shield, Zap, Clock, Sparkles, GraduationCap, Target } from 'lucide-react';
import { Resource, StudyTask } from '../types';
import Dashboard from './components/Dashboard';
import NeuralTimer from './components/NeuralTimer';
import StrategicPlanner from './components/StrategicPlanner';
import ResourceView from './components/ResourceView';
import UploadModal from './components/UploadModal';
import ExamGeneratorModal from './components/ExamGeneratorModal';
import LandingPage from './components/LandingPage';
import APCenter from './components/APCenter';
import SATPrep from './components/SATPrep';
import { Logo } from './components/Logo';
import { getResources } from './services/mockDb';
import { getUserTier, unlockSession, initIdleMonitor } from './utils/security';

const App: React.FC = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [currentView, setCurrentView] = useState<'dashboard' | 'timer' | 'planner' | 'ap-center' | 'sat-prep'>('dashboard');
  const [resourceViewId, setResourceViewId] = useState<string | null>(null);
  const [isUploadOpen, setIsUploadOpen] = useState(false);
  const [isExamOpen, setIsExamOpen] = useState(false);
  const [resources, setResources] = useState<Resource[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [userTier, setUserTier] = useState<string>('Initiate');
  const [currentUsername, setCurrentUsername] = useState<string>('');
  
  // Shared To-Do State
  const [todoTasks, setTodoTasks] = useState<StudyTask[]>([]);

  // Load Todos on Mount
  useEffect(() => {
    const savedTodos = localStorage.getItem('ascent_todos');
    if (savedTodos) {
      setTodoTasks(JSON.parse(savedTodos));
    }
  }, []);

  // Save Todos on Change
  useEffect(() => {
    if (isAuthenticated) {
      localStorage.setItem('ascent_todos', JSON.stringify(todoTasks));
    }
  }, [todoTasks, isAuthenticated]);

  const handleAddTodo = (text: string) => {
    setTodoTasks(prev => [{ id: Date.now().toString(), text, completed: false }, ...prev]);
  };

  const handleToggleTodo = (id: string) => {
    setTodoTasks(prev => prev.map(t => t.id === id ? { ...t, completed: !t.completed } : t));
  };

  const handleDeleteTodo = (id: string) => {
    setTodoTasks(prev => prev.filter(t => t.id !== id));
  };

  // Logout Logic
  const handleLogout = () => {
    localStorage.removeItem('ascent_session');
    localStorage.removeItem('ascent_user_tier');
    localStorage.removeItem('ascent_username');
    
    if (currentUsername) {
      unlockSession(currentUsername);
    }
    
    setIsAuthenticated(false);
    setCurrentView('dashboard');
    setCurrentUsername('');
  };

  // Check for existing session & Init Security Monitors
  useEffect(() => {
    const session = localStorage.getItem('ascent_session');
    const user = localStorage.getItem('ascent_username');
    if (session) {
      setIsAuthenticated(true);
      setUserTier(getUserTier());
      if (user) setCurrentUsername(user);
      
      // Init Idle Monitor
      initIdleMonitor(handleLogout);
    }

    // Safety: Unlock session if user closes tab
    const handleUnload = () => {
      if (user) unlockSession(user);
    };
    window.addEventListener('beforeunload', handleUnload);
    return () => window.removeEventListener('beforeunload', handleUnload);
  }, [isAuthenticated, currentUsername]);

  const handleLogin = (username: string) => {
    localStorage.setItem('ascent_session', 'true');
    localStorage.setItem('ascent_username', username);
    setCurrentUsername(username);
    setIsAuthenticated(true);
    setUserTier(getUserTier());
    // Init Idle Monitor immediately upon login
    initIdleMonitor(handleLogout);
  };

  const refreshResources = async () => {
    setIsLoading(true);
    const data = await getResources();
    setResources(data);
    setIsLoading(false);
  };

  useEffect(() => {
    if (isAuthenticated) {
      refreshResources();
      document.documentElement.classList.add('dark');
    }
  }, [isAuthenticated]);

  const handleResourceClick = (id: string) => {
    setResourceViewId(id);
  };

  const handleExamReady = (id: string) => {
    refreshResources();
    handleResourceClick(id); // Immediately open the new exam
  }

  const handleHomeClick = () => {
    setResourceViewId(null);
    setCurrentView('dashboard');
  };

  if (!isAuthenticated) {
    return <LandingPage onLogin={handleLogin} />;
  }

  // Determine what to render in the main content area
  let content;
  if (resourceViewId) {
    content = (
      <ResourceView 
        resourceId={resourceViewId} 
        onBack={() => setResourceViewId(null)}
        darkMode={true}
      />
    );
  } else {
    switch(currentView) {
      case 'dashboard':
        content = (
          <Dashboard 
            darkMode={true} 
            resources={resources} 
            onResourceClick={handleResourceClick}
            onUploadClick={() => setIsUploadOpen(true)}
            onExamClick={() => setIsExamOpen(true)}
            todoTasks={todoTasks}
            onAddTodo={handleAddTodo}
            onToggleTodo={handleToggleTodo}
            onDeleteTodo={handleDeleteTodo}
          />
        );
        break;
      case 'timer':
        content = <NeuralTimer />;
        break;
      case 'planner':
        content = <StrategicPlanner onAddToDashboard={handleAddTodo} />;
        break;
      case 'ap-center':
        content = <APCenter onExamReady={handleExamReady} />;
        break;
      case 'sat-prep':
        content = <SATPrep />;
        break;
    }
  }

  return (
    <div className="flex h-screen w-full overflow-hidden bg-[#030303] text-white selection:bg-primary-900/50 selection:text-white font-sans">
      
      {/* Sidebar */}
      <aside className="w-72 flex-shrink-0 flex flex-col border-r border-white/5 bg-[#050505] z-30 transition-all duration-500">
        <div className="p-8 flex items-center gap-3 cursor-pointer group" onClick={handleHomeClick}>
          <div className="transition-transform duration-500 group-hover:scale-110 group-hover:rotate-180">
            <Logo size={28} />
          </div>
          <span className="font-bold text-xl tracking-tight text-white group-hover:text-primary-400 transition-colors">ASCENT</span>
        </div>

        <div className="px-6 mb-8">
          <button 
            onClick={() => setIsUploadOpen(true)}
            className="w-full py-3.5 px-4 rounded-xl flex items-center justify-center gap-2 text-sm font-bold transition-all duration-300 bg-white text-black hover:bg-primary-500 hover:text-white hover:shadow-[0_0_20px_rgba(37,99,235,0.4)] transform hover:scale-[1.02] active:scale-[0.98] group"
          >
            <Plus size={18} className="group-hover:rotate-90 transition-transform duration-300" />
            <span>New Space</span>
          </button>
        </div>

        <nav className="flex-1 px-4 space-y-1 overflow-y-auto custom-scrollbar">
          <NavItem 
            icon={<Home size={18} />} 
            label="Command Center" 
            active={!resourceViewId && currentView === 'dashboard'} 
            onClick={() => { setCurrentView('dashboard'); setResourceViewId(null); }}
          />
          <NavItem 
            icon={<GraduationCap size={18} />} 
            label="AP Nexus" 
            active={!resourceViewId && currentView === 'ap-center'} 
            onClick={() => { setCurrentView('ap-center'); setResourceViewId(null); }}
          />
          <NavItem 
            icon={<Target size={18} />} 
            label="SAT Prep" 
            active={!resourceViewId && currentView === 'sat-prep'} 
            onClick={() => { setCurrentView('sat-prep'); setResourceViewId(null); }}
          />
          
          <div className="mt-8 mb-3 px-4 flex items-center justify-between">
            <span className="text-[10px] font-bold uppercase tracking-widest text-zinc-600">Encrypted Library</span>
            <span className="bg-zinc-900/50 border border-white/5 text-zinc-500 px-1.5 py-0.5 rounded text-[10px] font-mono">{resources.length}</span>
          </div>
          
          <div className="space-y-1">
            {resources.map(res => (
              <NavItem 
                key={res.id}
                icon={<FileText size={18} />} 
                label={res.title} 
                active={resourceViewId === res.id}
                onClick={() => handleResourceClick(res.id)}
              />
            ))}
          </div>
        </nav>

        <div className="p-4 border-t border-white/5 mt-auto bg-[#050505]">
          <div className="flex items-center gap-3 p-3 rounded-xl bg-zinc-900/30 border border-white/5 mb-3">
            <div className={`w-8 h-8 rounded-full shadow-lg ring-2 ring-black bg-gradient-to-tr ${userTier === 'Scholar' ? 'from-purple-600 to-primary-600' : 'from-zinc-600 to-zinc-400'}`}></div>
            <div className="flex-1 min-w-0">
              <div className="font-bold text-sm text-white truncate">
                {userTier === 'Scholar' ? 'Scholar Client' : 'Initiate'}
              </div>
              <div className="text-[10px] text-primary-400 font-mono tracking-wider flex items-center gap-1">
                <span className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse"></span> ONLINE
              </div>
            </div>
            <Shield size={14} className="text-zinc-600" />
          </div>
          <button 
            onClick={handleLogout}
            className="w-full flex items-center justify-center gap-2 py-2.5 rounded-lg text-xs font-medium text-zinc-500 hover:text-red-400 hover:bg-red-950/20 transition-colors"
          >
            <LogOut size={14} /> Sign Out
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 relative bg-[#030303]">
        
        {/* Top Navigation Bar */}
        {!resourceViewId && (
          <header className="h-20 w-full flex items-center justify-center sticky top-0 z-20 pointer-events-none">
            <nav className="flex items-center gap-1 p-1.5 bg-zinc-900/80 backdrop-blur-xl rounded-full border border-white/10 shadow-2xl mt-4 pointer-events-auto transition-all duration-300 hover:border-white/20">
              <TopNavLink 
                active={currentView === 'dashboard'} 
                onClick={() => setCurrentView('dashboard')} 
                label="Command Center"
                icon={<Home size={14} />}
              />
              <TopNavLink 
                active={currentView === 'ap-center'} 
                onClick={() => setCurrentView('ap-center')} 
                label="AP Nexus"
                icon={<GraduationCap size={14} />}
              />
              <TopNavLink 
                active={currentView === 'sat-prep'} 
                onClick={() => setCurrentView('sat-prep')} 
                label="SAT Prep"
                icon={<Target size={14} />}
              />
              <TopNavLink 
                active={currentView === 'timer'} 
                onClick={() => setCurrentView('timer')} 
                label="Neural Timer"
                icon={<Clock size={14} />}
              />
              <TopNavLink 
                active={currentView === 'planner'} 
                onClick={() => setCurrentView('planner')} 
                label="Strategic Planner"
                icon={<Sparkles size={14} />}
              />
            </nav>
          </header>
        )}

        {/* View Content */}
        <div className="flex-1 overflow-y-auto overflow-x-hidden p-8 scroll-smooth scrollbar-thin scrollbar-thumb-zinc-800 scrollbar-track-transparent">
           <div className="w-full h-full transition-all duration-500">
             {content}
           </div>
        </div>
      </main>

      {/* Modals */}
      {isUploadOpen && (
        <UploadModal 
          isOpen={isUploadOpen} 
          onClose={() => setIsUploadOpen(false)} 
          onUploadComplete={refreshResources}
          darkMode={true}
        />
      )}
      
      {isExamOpen && (
        <ExamGeneratorModal 
          isOpen={isExamOpen}
          onClose={() => setIsExamOpen(false)}
          onExamReady={handleExamReady}
        />
      )}
    </div>
  );
};

const NavItem = ({ icon, label, active, onClick }: any) => (
  <button
    onClick={onClick}
    className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all duration-300 mb-1 group relative overflow-hidden ${
      active 
        ? 'bg-primary-600/10 text-white shadow-lg' 
        : 'text-zinc-500 hover:text-white hover:bg-white/5'
    }`}
  >
    {active && (
      <div className="absolute left-0 top-0 bottom-0 w-1 bg-primary-500 rounded-r-full"></div>
    )}
    <span className={`transition-colors duration-300 ${active ? 'text-primary-400' : 'group-hover:text-zinc-300'}`}>{icon}</span>
    <span className="truncate relative z-10">{label}</span>
  </button>
);

const TopNavLink = ({ active, onClick, label, icon }: any) => (
  <button
    onClick={onClick}
    className={`px-5 py-2 rounded-full text-xs font-bold transition-all duration-300 flex items-center gap-2 relative overflow-hidden group ${
      active 
        ? 'text-white shadow-lg bg-zinc-800' 
        : 'text-zinc-500 hover:text-white hover:bg-white/5'
    }`}
  >
    {active && <div className="absolute inset-0 bg-gradient-to-tr from-white/10 to-transparent opacity-50"></div>}
    <span className="relative z-10 flex items-center gap-2">
      {icon}
      {label}
    </span>
  </button>
);

export default App;
