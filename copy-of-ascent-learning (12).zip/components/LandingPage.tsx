
import React, { useState, useEffect } from 'react';
import { Shield, Zap, Brain, ArrowRight, Check, X, Globe, Cpu, Lock, ChevronRight, Activity, Users, Database, Layers, Rocket, AlertTriangle, Terminal, Hourglass } from 'lucide-react';
import { Logo } from './Logo';
import { lockSession, unlockSession } from '../utils/security';

interface LandingPageProps {
  onLogin: (username: string) => void;
}

// STRICT ACCESS CONTROL - 15 SLOTS ONLY
const ACCESS_KEYS = Array.from({ length: 15 }, (_, i) => `PILOT-${String(i + 1).padStart(2, '0')}`);

const LandingPage: React.FC<LandingPageProps> = ({ onLogin }) => {
  const [showLoginModal, setShowLoginModal] = useState(false);
  const [showContactModal, setShowContactModal] = useState(false);
  const [showWaitlistModal, setShowWaitlistModal] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  // Login State
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loginError, setLoginError] = useState('');
  const [isAuthenticating, setIsAuthenticating] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const handleLoginSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');
    
    const inputId = username.trim();

    if (!inputId) {
        setLoginError('Identity required.');
        return;
    }

    setIsAuthenticating(true);

    // Simulated network delay
    setTimeout(() => {
      // 1. SCHOLAR LOGIN (Premium - Admin Backdoor)
      if (inputId === 'Client_Login' && password === 'Pradyun@19') {
        localStorage.setItem('ascent_user_tier', 'Scholar');
        handleSuccessfulLogin(inputId);
        return;
      } 
      
      // 2. CHECK ACCESS KEYS (Strict 15 User Limit)
      // Case-insensitive check against the 15 allowed keys
      const isValidKey = ACCESS_KEYS.includes(inputId.toUpperCase());

      if (isValidKey) {
        // ACCESS GRANTED
        localStorage.setItem('ascent_user_tier', 'Initiate');
        handleSuccessfulLogin(inputId.toUpperCase());
      } else {
        // ACCESS DENIED -> WAITLIST
        setIsAuthenticating(false);
        setShowLoginModal(false);
        setShowWaitlistModal(true);
      }
      
    }, 1200);
  };

  const handleSuccessfulLogin = (user: string) => {
    // Update Streak Logic
    const lastLogin = localStorage.getItem('ascent_last_login');
    const currentStreak = parseInt(localStorage.getItem('ascent_streak') || '0');
    const today = new Date().toDateString();

    if (lastLogin !== today) {
        const yesterday = new Date();
        yesterday.setDate(yesterday.getDate() - 1);
        
        if (lastLogin === yesterday.toDateString()) {
            localStorage.setItem('ascent_streak', (currentStreak + 1).toString());
        } else {
            localStorage.setItem('ascent_streak', '1');
        }
        localStorage.setItem('ascent_last_login', today);
    }

    lockSession(user);
    onLogin(user);
  };

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-[#000000] text-white selection:bg-primary-600 selection:text-white flex flex-col overflow-x-hidden font-sans relative">
      
      {/* Aurora Background Mesh */}
      <div className="fixed inset-0 z-0 pointer-events-none overflow-hidden">
        <div className="absolute top-[-20%] left-[-10%] w-[70vw] h-[70vw] bg-primary-900/10 rounded-full blur-[120px] animate-float opacity-40" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[60vw] h-[60vw] bg-accent-purple/10 rounded-full blur-[120px] animate-pulse-slow opacity-30" />
        <div className="absolute top-[40%] right-[20%] w-[40vw] h-[40vw] bg-primary-800/10 rounded-full blur-[100px] animate-float opacity-30" style={{ animationDelay: '2s' }} />
      </div>

      {/* Nav */}
      <nav className={`fixed top-0 w-full z-50 transition-all duration-500 ${scrolled ? 'bg-black/80 backdrop-blur-xl border-b border-white/5 py-4' : 'bg-transparent py-6'}`}>
        <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
          <div className="flex items-center gap-3 cursor-pointer group" onClick={() => window.scrollTo({top: 0, behavior: 'smooth'})}>
            <div className="transition-transform duration-300 group-hover:scale-110">
              <Logo size={32} />
            </div>
            <span className="font-bold text-2xl tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-white via-primary-200 to-primary-500 group-hover:text-glow transition-all">
              ASCENT
            </span>
          </div>
          <div className="flex items-center gap-8">
            <div className="hidden md:flex items-center gap-8 text-sm font-medium text-zinc-400">
              <button onClick={() => scrollToSection('process')} className="hover:text-white transition-colors relative group">
                Process
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-primary-500 transition-all group-hover:w-full"></span>
              </button>
              <button onClick={() => scrollToSection('features')} className="hover:text-white transition-colors relative group">
                Protocol
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-primary-500 transition-all group-hover:w-full"></span>
              </button>
              <button onClick={() => scrollToSection('pricing')} className="hover:text-white transition-colors relative group">
                Access
                <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-primary-500 transition-all group-hover:w-full"></span>
              </button>
            </div>
            <button 
              onClick={() => setShowLoginModal(true)}
              className="text-sm font-bold px-6 py-2.5 rounded-full border border-white/10 bg-white/5 hover:bg-white/10 hover:border-white/20 transition-all shadow-[0_0_15px_rgba(0,0,0,0.5)] active:scale-95 flex items-center gap-2 group hover:text-primary-400"
            >
              <Lock size={14} className="group-hover:text-primary-400 transition-colors" />
              Secure Login
            </button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <main className="flex-1 flex flex-col items-center pt-40 pb-20 px-6 relative z-10">
        <div className="max-w-5xl mx-auto text-center space-y-10 animate-enter">
          
          {/* UPDATED: Clean System Status Badge */}
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-primary-900/10 border border-primary-500/20 text-xs font-bold tracking-wider text-primary-400 uppercase backdrop-blur-md">
            <span className="w-1.5 h-1.5 rounded-full bg-primary-500 animate-pulse"></span>
            System Operational
          </div>
          
          <h1 className="text-6xl md:text-8xl font-black tracking-tighter leading-[0.95] text-glow">
            Accelerate <br />
            <span className="text-transparent bg-clip-text bg-gradient-to-b from-white to-zinc-500">Cognitive</span>
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary-500 to-accent-purple ml-4 animate-pulse-slow">Evolution</span>
          </h1>
          
          <p className="text-xl md:text-2xl text-zinc-400 max-w-2xl mx-auto leading-relaxed font-light stagger-1 animate-enter">
            The elite AI-powered knowledge engine. Transform chaotic information streams into structured, retrievable mastery.
          </p>

          <div className="flex flex-col md:flex-row items-center justify-center gap-6 pt-6 stagger-2 animate-enter">
            <button 
              onClick={() => setShowLoginModal(true)}
              className="relative px-10 py-5 rounded-full bg-primary-600 text-white font-bold text-lg transition-all hover:scale-105 active:scale-95 shadow-[0_0_40px_rgba(41,98,255,0.4)] hover:shadow-[0_0_60px_rgba(41,98,255,0.6)] group overflow-hidden"
            >
              <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/20 to-transparent translate-x-[-100%] group-hover:translate-x-[100%] transition-transform duration-1000" />
              <span className="relative flex items-center gap-3">
                Initialize Ascent
                <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
              </span>
            </button>
            <button onClick={() => scrollToSection('features')} className="px-10 py-5 rounded-full border border-white/10 bg-white/5 hover:bg-white/10 text-white font-bold text-lg transition-all hover:scale-105">
              View Protocol
            </button>
          </div>
        </div>

        {/* Dashboard Preview / Hologram */}
        <div className="mt-32 w-full max-w-6xl mx-auto animate-enter stagger-3 relative">
          <div className="absolute -inset-1 bg-gradient-to-r from-primary-600 via-accent-cyan to-primary-600 opacity-30 blur-2xl rounded-[2rem]"></div>
          <div className="relative rounded-2xl border border-white/10 bg-[#050505] p-2 shadow-2xl overflow-hidden group">
             <div className="absolute top-0 left-0 w-full h-px bg-gradient-to-r from-transparent via-white/20 to-transparent"></div>
             
             {/* Mock UI */}
             <div className="aspect-[16/9] bg-black rounded-xl overflow-hidden relative flex flex-col">
                <div className="h-12 border-b border-white/10 flex items-center px-4 gap-2 bg-[#0A0A0A]">
                   <div className="flex gap-2">
                     <div className="w-3 h-3 rounded-full bg-red-500/20 border border-red-500/50"></div>
                     <div className="w-3 h-3 rounded-full bg-yellow-500/20 border border-yellow-500/50"></div>
                     <div className="w-3 h-3 rounded-full bg-green-500/20 border border-green-500/50"></div>
                   </div>
                   <div className="ml-4 px-3 py-1 bg-black rounded-md border border-white/5 text-[10px] text-zinc-500 font-mono w-64 flex justify-between">
                      <span>ascent://dashboard</span>
                      <Lock size={10} />
                   </div>
                </div>
                <div className="flex-1 flex items-center justify-center relative">
                   <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-primary-900/20 via-black to-black opacity-50"></div>
                   <div className="text-center space-y-6 relative z-10 transform transition-transform duration-700 group-hover:scale-105">
                      <div className="w-24 h-24 mx-auto rounded-full bg-primary-500/10 border border-primary-500/50 flex items-center justify-center animate-pulse-slow shadow-[0_0_30px_rgba(41,98,255,0.2)]">
                        <Cpu size={40} className="text-primary-400" />
                      </div>
                      <div>
                        <div className="text-3xl font-bold text-white mb-2">Neural Synthesis Active</div>
                        <div className="text-zinc-500 font-mono text-sm">Processing 2.4TB Knowledge Graphs...</div>
                      </div>
                   </div>
                </div>
             </div>
          </div>
        </div>
      </main>

      {/* Metrics Section */}
      <section className="py-24 bg-[#050505] border-y border-white/5 relative overflow-hidden">
        <div className="absolute left-0 top-0 w-full h-full bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-5"></div>
        <div className="max-w-7xl mx-auto px-6 relative z-10">
           <div className="grid grid-cols-2 md:grid-cols-4 gap-12 text-center">
              <div className="space-y-2">
                 <div className="text-4xl md:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-b from-white to-zinc-600">99.8%</div>
                 <div className="text-sm font-mono text-primary-400 uppercase tracking-widest">Accuracy Rate</div>
              </div>
              <div className="space-y-2">
                 <div className="text-4xl md:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-b from-white to-zinc-600">200k+</div>
                 <div className="text-sm font-mono text-primary-400 uppercase tracking-widest">Context Window</div>
              </div>
              <div className="space-y-2">
                 <div className="text-4xl md:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-b from-white to-zinc-600">&lt;50ms</div>
                 <div className="text-sm font-mono text-primary-400 uppercase tracking-widest">Recall Latency</div>
              </div>
              <div className="space-y-2">
                 <div className="text-4xl md:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-b from-white to-zinc-600">AES-256</div>
                 <div className="text-sm font-mono text-primary-400 uppercase tracking-widest">Encryption</div>
              </div>
           </div>
        </div>
      </section>

      {/* Process Section */}
      <section id="process" className="py-32 relative">
        <div className="max-w-7xl mx-auto px-6">
          <div className="text-center mb-20 space-y-4">
            <h2 className="text-4xl md:text-6xl font-bold tracking-tight">The Ascent Protocol</h2>
            <p className="text-zinc-400 text-lg">From chaotic input to structured mastery in three computational steps.</p>
          </div>
          
          <div className="grid md:grid-cols-3 gap-8 relative">
             <div className="absolute top-1/2 left-0 w-full h-1 bg-gradient-to-r from-transparent via-white/10 to-transparent hidden md:block"></div>
             <StepCard num="01" title="Data Ingestion" desc="Upload PDFs, paste links, or record lectures. Our multi-modal engine parses audio, video, and text streams instantly." />
             <StepCard num="02" title="Neural Synthesis" desc="The AI architect restructures information into high-fidelity summaries, extracting key relationships and hidden patterns." />
             <StepCard num="03" title="Active Recall" desc="Automated flashcard generation and adaptive quizzing reinforce neural pathways for long-term retention." />
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section id="features" className="py-32 bg-[#080808] border-y border-white/5">
        <div className="max-w-7xl mx-auto px-6">
           <div className="flex flex-col md:flex-row justify-between items-end mb-20 gap-8">
              <div>
                 <h2 className="text-4xl font-bold mb-4">Command Center Capabilities</h2>
                 <p className="text-zinc-400 max-w-md">A suite of military-grade cognitive tools designed for the modern scholar.</p>
              </div>
              <button onClick={() => setShowLoginModal(true)} className="px-8 py-4 rounded-full border border-white/10 hover:bg-white/5 transition-colors flex items-center gap-2 group">
                 Explore All Features <ChevronRight className="group-hover:translate-x-1 transition-transform" />
              </button>
           </div>

           <div className="grid md:grid-cols-3 gap-6">
              <FeatureCard 
                icon={<Database size={32} className="text-primary-400" />}
                title="Knowledge Vault"
                desc="Securely store and organize unlimited course materials with encrypted access protocols."
                delay="stagger-1"
              />
              <FeatureCard 
                icon={<Brain size={32} className="text-accent-purple" />}
                title="Neural Flashcards"
                desc="AI identifies high-yield concepts and generates spaced-repetition decks automatically."
                delay="stagger-2"
              />
              <FeatureCard 
                icon={<Zap size={32} className="text-yellow-400" />}
                title="Exam Simulation"
                desc="Generate comprehensive, difficulty-calibrated exams from your study materials in seconds."
                delay="stagger-3"
              />
              <FeatureCard 
                icon={<Globe size={32} className="text-green-400" />}
                title="Search Grounding"
                desc="Verify facts with real-time web access. Cross-reference uploaded notes with global data."
                delay="stagger-1"
              />
              <FeatureCard 
                icon={<Activity size={32} className="text-red-400" />}
                title="Focus Telemetry"
                desc="Track learning velocity and retention rates with precision analytics dashboards."
                delay="stagger-2"
              />
              <FeatureCard 
                icon={<Users size={32} className="text-cyan-400" />}
                title="Collaborative Sync"
                desc="Scholar tier allows for secure team-based knowledge sharing and synthesis."
                delay="stagger-3"
              />
           </div>
        </div>
      </section>

      {/* Pricing */}
      <section id="pricing" className="py-32 relative">
         <div className="absolute inset-0 bg-gradient-to-b from-[#080808] to-black pointer-events-none"></div>
         <div className="max-w-7xl mx-auto px-6 relative z-10">
            <div className="text-center mb-20">
               <h2 className="text-4xl font-bold mb-4">Clearance Levels</h2>
               <p className="text-zinc-400">Select the protocol tier that matches your cognitive requirements.</p>
            </div>

            <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
               <PricingCard 
                 tier="Initiate" 
                 price="$0" 
                 desc="Essential tools for the aspiring learner."
                 features={['Daily Access Limit', 'Basic Synthesis Engine', 'Standard Support', 'Core AP Courses']}
                 highlight={false}
                 onSelect={() => setShowLoginModal(true)}
               />
               <PricingCard 
                 tier="Scholar" 
                 price="$9.99" 
                 desc="The ultimate cognitive augmentation suite."
                 features={['Unlimited Uploads', 'Priority Neural Access', 'Full AP Nexus Access', 'Advanced Analytics', 'SAT Mastery Engine', 'Priority Support']}
                 highlight={true}
                 onSelect={() => setShowLoginModal(true)}
               />
            </div>
         </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-white/5 bg-[#020202] py-20">
         <div className="max-w-7xl mx-auto px-6 grid md:grid-cols-4 gap-12">
            <div className="space-y-6">
               <div className="flex items-center gap-2">
                  <Logo size={24} />
                  <span className="font-bold text-xl tracking-tight text-white">ASCENT</span>
               </div>
               <p className="text-zinc-500 text-sm leading-relaxed">
                  Accelerating human potential through high-bandwidth neural interfaces and structured knowledge synthesis.
               </p>
            </div>
            
            <div>
               <h4 className="font-bold text-white mb-6">Platform</h4>
               <ul className="space-y-4 text-sm text-zinc-500">
                  <li><button onClick={() => setShowLoginModal(true)} className="hover:text-white transition-colors">Login</button></li>
                  <li><button onClick={() => scrollToSection('features')} className="hover:text-white transition-colors">Features</button></li>
                  <li><button onClick={() => scrollToSection('pricing')} className="hover:text-white transition-colors">Pricing</button></li>
               </ul>
            </div>

            <div>
               <h4 className="font-bold text-white mb-6">Legal</h4>
               <ul className="space-y-4 text-sm text-zinc-500">
                  <li><a href="#" className="hover:text-white transition-colors">Privacy Protocol</a></li>
                  <li><a href="#" className="hover:text-white transition-colors">Terms of Service</a></li>
                  <li><a href="#" className="hover:text-white transition-colors">Data Security</a></li>
               </ul>
            </div>

            <div>
               <h4 className="font-bold text-white mb-6">Connect</h4>
               <div className="flex gap-4">
                  <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-white/10 transition-colors text-zinc-400 hover:text-white">
                     <Rocket size={18} />
                  </a>
                  <a href="#" className="w-10 h-10 rounded-full bg-white/5 flex items-center justify-center hover:bg-white/10 transition-colors text-zinc-400 hover:text-white">
                     <Globe size={18} />
                  </a>
               </div>
            </div>
         </div>
         <div className="mt-20 text-center text-zinc-600 text-xs font-mono uppercase tracking-widest">
            © 2025 Ascent Learning Systems. All Rights Reserved.
         </div>
      </footer>

      {/* Login Modal */}
      {showLoginModal && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/80 backdrop-blur-xl p-4 animate-enter duration-200">
          <div className="w-full max-w-md bg-[#0A0A0A] border border-white/10 rounded-3xl p-8 relative shadow-2xl overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-primary-600 via-accent-purple to-primary-600 animate-[aurora_3s_linear_infinite]"></div>
            
            <button onClick={() => setShowLoginModal(false)} className="absolute top-4 right-4 text-zinc-500 hover:text-white transition-colors">
              <X size={20} />
            </button>
            
            <div className="text-center mb-8">
              <Logo size={48} className="mx-auto mb-4" />
              <h3 className="text-2xl font-bold text-white mb-1">Secure Login</h3>
              <p className="text-zinc-500 text-sm">System Capacity: 15/15 Pilots.</p>
            </div>

            <form onSubmit={handleLoginSubmit} className="space-y-4">
              <div className="space-y-1">
                <label className="text-xs font-mono text-zinc-500 uppercase ml-1">Access Key</label>
                <input 
                  type="text" 
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="w-full bg-black border border-white/10 rounded-xl p-3.5 text-white focus:border-primary-500 outline-none transition-all focus:shadow-[0_0_15px_rgba(41,98,255,0.1)] placeholder:text-zinc-700"
                  autoFocus
                />
              </div>
              <div className="space-y-1">
                <label className="text-xs font-mono text-zinc-500 uppercase ml-1">Passkey</label>
                <input 
                  type="password" 
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-black border border-white/10 rounded-xl p-3.5 text-white focus:border-primary-500 outline-none transition-all focus:shadow-[0_0_15px_rgba(41,98,255,0.1)] placeholder:text-zinc-700"
                />
              </div>

              {loginError && (
                 <div className="p-3 bg-red-900/10 border border-red-900/30 rounded-xl text-red-400 text-xs text-center font-bold animate-pulse">
                   {loginError}
                 </div>
              )}

              <button 
                type="submit" 
                disabled={isAuthenticating}
                className="w-full py-4 bg-primary-600 hover:bg-primary-500 text-white font-bold rounded-xl transition-all shadow-[0_0_20px_rgba(41,98,255,0.3)] hover:shadow-[0_0_30px_rgba(41,98,255,0.5)] transform hover:-translate-y-0.5 disabled:opacity-50 disabled:cursor-not-allowed mt-2"
              >
                {isAuthenticating ? (
                  <span className="flex items-center justify-center gap-2">
                    <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin"></span>
                    Verifying Credentials...
                  </span>
                ) : 'Verify Identity'}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Waitlist Modal */}
      {showWaitlistModal && (
        <div className="fixed inset-0 z-[70] flex items-center justify-center bg-black/95 backdrop-blur-xl p-4 animate-enter duration-300">
           <div className="w-full max-w-md bg-[#050505] border border-red-900/30 rounded-3xl p-8 relative shadow-2xl overflow-hidden text-center">
              {/* Spinning Red Warning */}
              <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-red-600 to-transparent animate-pulse"></div>
              
              <div className="w-20 h-20 rounded-full bg-red-900/10 border border-red-500/20 flex items-center justify-center mx-auto mb-6">
                 <Hourglass size={32} className="text-red-500 animate-pulse" />
              </div>
              
              <h2 className="text-3xl font-black text-white mb-2 tracking-tight">Access Denied</h2>
              <div className="inline-block px-3 py-1 bg-red-900/20 border border-red-500/20 rounded-full text-red-400 text-[10px] font-bold uppercase tracking-widest mb-6">
                System Capacity Reached
              </div>
              
              <p className="text-zinc-400 text-sm leading-relaxed mb-8">
                The Ascent Protocol is currently operating at max pilot capacity (15/15). 
                Your Neural ID has been placed in the priority queue.
              </p>

              <div className="bg-zinc-900/50 rounded-xl p-4 mb-8 border border-white/5">
                 <div className="text-[10px] text-zinc-500 font-mono uppercase tracking-widest mb-1">Current Queue Position</div>
                 <div className="text-2xl font-bold text-white">#2,401</div>
              </div>

              <div className="flex flex-col gap-3">
                 <button 
                   onClick={() => { setShowWaitlistModal(false); setShowLoginModal(true); }}
                   className="w-full py-3.5 rounded-xl border border-white/10 hover:bg-white/5 text-white font-bold text-sm transition-all"
                 >
                   Try Different Key
                 </button>
                 <button 
                   onClick={() => { setShowWaitlistModal(false); }}
                   className="text-xs text-zinc-500 hover:text-white transition-colors"
                 >
                   Exit Protocol
                 </button>
              </div>
           </div>
        </div>
      )}

      {/* Scholar Contact Modal */}
      {showContactModal && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-enter duration-200">
          <div className="w-full max-w-md bg-[#0A0A0A] border border-white/10 rounded-2xl p-8 relative shadow-2xl overflow-hidden">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-primary-600 via-accent-cyan to-primary-600"></div>
            <button onClick={() => setShowContactModal(false)} className="absolute top-4 right-4 text-zinc-500 hover:text-white transition-colors"><X size={20} /></button>
            <div className="text-center mb-6">
              <div className="w-16 h-16 bg-primary-900/10 rounded-full flex items-center justify-center mx-auto mb-4 text-primary-400 border border-primary-500/20"><Shield size={28} /></div>
              <h3 className="text-xl font-bold text-white mb-2">Scholar Solutions</h3>
              <p className="text-zinc-400 text-sm">Deploy Ascent securely within your organization.</p>
            </div>
            <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); setShowContactModal(false); alert("Request Sent!"); }}>
              <div className="space-y-1"><label className="text-xs font-mono text-zinc-500 uppercase ml-1">Work Email</label><input type="email" placeholder="name@company.com" className="w-full bg-black border border-white/10 rounded-xl p-3 text-white focus:border-primary-500 outline-none" required /></div>
              <button type="submit" className="w-full py-3.5 bg-primary-600 hover:bg-primary-500 text-white font-bold rounded-xl shadow-[0_0_20px_rgba(41,98,255,0.3)]">Request Access</button>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

const FeatureCard = ({ icon, title, desc, delay }: any) => (
  <div className={`p-8 rounded-3xl bg-[#0A0A0A] border border-white/5 hover:border-primary-500/30 transition-all duration-300 group hover:-translate-y-2 animate-enter ${delay}`}>
    <div className="w-16 h-16 rounded-2xl bg-white/5 flex items-center justify-center mb-6 group-hover:bg-primary-900/20 group-hover:scale-110 transition-all border border-white/5 group-hover:border-primary-500/20">
      {icon}
    </div>
    <h3 className="text-xl font-bold mb-3 text-white group-hover:text-primary-400 transition-colors">{title}</h3>
    <p className="text-zinc-400 leading-relaxed">{desc}</p>
  </div>
);

const StepCard = ({ num, title, desc }: any) => (
  <div className="relative p-8 rounded-3xl border border-white/5 hover:border-primary-500/50 bg-[#0A0A0A] group h-full transition-all duration-300 hover:bg-[#0F0F0F]">
    <div className="text-6xl font-black text-zinc-900 absolute top-4 right-4 z-0 group-hover:text-primary-900/20 transition-colors select-none opacity-50">{num}</div>
    <div className="relative z-10 flex flex-col h-full">
       <h3 className="text-xl font-bold text-white mb-3">{title}</h3>
       <p className="text-zinc-500 text-sm leading-relaxed">{desc}</p>
    </div>
  </div>
);

const PricingCard = ({ tier, price, desc, features, highlight, onSelect }: any) => (
  <div className={`p-8 rounded-3xl border flex flex-col transition-all duration-300 hover:-translate-y-2 ${highlight ? 'bg-primary-900/10 border-primary-500/50 shadow-[0_0_30px_rgba(41,98,255,0.1)]' : 'bg-[#0A0A0A] border-white/5'}`}>
    <div className="mb-6">
      <h3 className={`text-lg font-bold mb-2 ${highlight ? 'text-primary-400' : 'text-white'}`}>{tier}</h3>
      <div className="flex items-baseline gap-1">
        <span className="text-4xl font-bold text-white">{price}</span>
        {price !== 'Custom' && price !== '$0' && <span className="text-zinc-500">/mo</span>}
      </div>
      <p className="text-zinc-500 text-sm mt-3">{desc}</p>
    </div>
    <div className="flex-1 space-y-4 mb-8">
      {features.map((f: string, i: number) => (
        <div key={i} className="flex items-center gap-3 text-sm text-zinc-300">
          <Check size={16} className={highlight ? 'text-primary-400' : 'text-zinc-600'} />
          {f}
        </div>
      ))}
    </div>
    <button onClick={onSelect} className={`w-full py-3 rounded-xl font-bold text-sm transition-all ${highlight ? 'bg-primary-600 text-white hover:bg-primary-500 shadow-lg' : 'bg-white/5 text-white hover:bg-white/10'}`}>
      Select Tier
    </button>
  </div>
);

export default LandingPage;
