
import React, { useState, useEffect } from 'react';
import { BookOpen, ChevronRight, GraduationCap, ArrowLeft, Brain, Zap, Target, Layers, Play, CheckCircle, Lock } from 'lucide-react';
import { AP_COURSES, APCourse, APUnit } from '../data/apCourses';
import { generateAPSummary, generateAPQuiz, generateFlashcards } from '../services/geminiService';
import { createResource } from '../services/mockDb';
import { Resource } from '../types';
import { getUserTier } from '../utils/security';

interface APCenterProps {
  onExamReady: (id: string) => void;
}

const APCenter: React.FC<APCenterProps> = ({ onExamReady }) => {
  const [selectedCourse, setSelectedCourse] = useState<APCourse | null>(null);
  const [loadingUnit, setLoadingUnit] = useState<string | null>(null);
  const [loadingExam, setLoadingExam] = useState(false);
  const [userTier, setUserTier] = useState<string>('Initiate');

  // List of IDs accessible to Initiate tier
  // UPDATED: Removed Physics C Mech, Art History, Physics 2 per request.
  const INITIATE_ACCESS_IDS = [
    'ap-world', 
    'ap-stats', 
    'ap-physics-1', 
    'ap-physics-c-em', 
    'ap-human-geo'
  ];

  useEffect(() => {
    setUserTier(getUserTier());
  }, []);

  const getCategoryColor = (cat: string) => {
    switch (cat) {
      case 'Math': return 'text-blue-400 bg-blue-500/10 border-blue-500/20';
      case 'Science': return 'text-green-400 bg-green-500/10 border-green-500/20';
      case 'History': return 'text-orange-400 bg-orange-500/10 border-orange-500/20';
      case 'Computer Science': return 'text-purple-400 bg-purple-500/10 border-purple-500/20';
      default: return 'text-zinc-400 bg-zinc-800 border-zinc-700';
    }
  };

  const isLocked = (courseId: string) => {
    if (userTier === 'Scholar') return false;
    return !INITIATE_ACCESS_IDS.includes(courseId);
  };

  const handleCourseSelect = (course: APCourse) => {
    if (isLocked(course.id)) {
        alert("Access Restricted. Upgrade to Scholar to unlock this AP Course.");
        return;
    }
    setSelectedCourse(course);
  };

  const handleStudyUnit = async (unit: APUnit, index: number) => {
    if (loadingUnit) return;
    setLoadingUnit(unit.title);

    try {
      const topicString = `AP Course: ${selectedCourse?.title}. Unit: ${unit.title}. Topics: ${unit.topics}.`;
      
      const [summary, quiz, flashcards] = await Promise.all([
        generateAPSummary(topicString),
        generateAPQuiz(topicString, 20),
        generateFlashcards(topicString)
      ]);

      const resource: Resource = {
        id: `ap-${Date.now()}`,
        title: `${selectedCourse?.title}: ${unit.title}`,
        type: 'TEXT',
        originalContent: topicString, // Meta-content
        summary,
        flashcards,
        quiz,
        createdAt: Date.now(),
        lastAccessed: Date.now(),
        status: 'ready',
        tags: ['AP Nexus', selectedCourse?.title || 'AP', 'Unit Study']
      };

      await createResource(resource);
      onExamReady(resource.id);

    } catch (e) {
      console.error(e);
      alert("Neural Link Failed. Please try again.");
    } finally {
      setLoadingUnit(null);
    }
  };

  const handleComprehensiveExam = async () => {
    if (!selectedCourse || loadingExam) return;
    setLoadingExam(true);

    try {
      const allTopics = selectedCourse.units.map(u => `${u.title}: ${u.topics}`).join('\n');
      const topicString = `Comprehensive Review for ${selectedCourse.title}. Covering all units:\n${allTopics}`;

      const quiz = await generateAPQuiz(topicString, 50);
      
      const resource: Resource = {
        id: `ap-final-${Date.now()}`,
        title: `${selectedCourse.title} - Final Protocol`,
        type: 'TEXT',
        originalContent: topicString,
        summary: `<h2>Comprehensive Assessment Protocol</h2><p>This exam module covers all units of ${selectedCourse.title}.</p>`,
        flashcards: [], 
        quiz,
        createdAt: Date.now(),
        lastAccessed: Date.now(),
        status: 'ready',
        tags: ['AP Nexus', 'Exam Mode', 'Cumulative']
      };

      await createResource(resource);
      onExamReady(resource.id);
    } catch (e) {
      console.error(e);
      alert("Exam generation failed. Try again.");
    } finally {
      setLoadingExam(false);
    }
  };

  // Sort courses: Unlocked (Free) first, then Locked
  const sortedCourses = [...AP_COURSES].sort((a, b) => {
    const isAFree = INITIATE_ACCESS_IDS.includes(a.id);
    const isBFree = INITIATE_ACCESS_IDS.includes(b.id);
    if (isAFree && !isBFree) return -1;
    if (!isAFree && isBFree) return 1;
    return 0; 
  });

  if (selectedCourse) {
    return (
      <div className="max-w-5xl mx-auto py-8 animate-enter">
        <button 
          onClick={() => setSelectedCourse(null)}
          className="flex items-center gap-2 text-xs font-bold uppercase tracking-widest text-zinc-500 hover:text-white mb-8 group transition-colors"
        >
          <ArrowLeft size={14} className="group-hover:-translate-x-1 transition-transform" /> Return to AP Nexus
        </button>

        <div className="flex flex-col md:flex-row gap-8 items-start mb-12 border-b border-white/5 pb-12">
           <div className={`w-20 h-20 rounded-2xl flex items-center justify-center text-3xl shadow-[0_0_30px_rgba(0,0,0,0.5)] ${getCategoryColor(selectedCourse.category)}`}>
             <GraduationCap />
           </div>
           <div className="flex-1">
             <div className="flex items-center gap-3 mb-2">
                <span className={`text-[10px] font-bold px-2 py-0.5 rounded uppercase tracking-wider border ${getCategoryColor(selectedCourse.category)} bg-transparent`}>
                  {selectedCourse.category}
                </span>
                <span className="text-[10px] font-mono text-zinc-600 uppercase">COURSE ID: {selectedCourse.id.toUpperCase()}</span>
             </div>
             <h1 className="text-4xl font-bold text-white mb-4">{selectedCourse.title}</h1>
             <p className="text-zinc-400 text-lg leading-relaxed max-w-2xl">{selectedCourse.description}</p>
           </div>
           <div className="flex flex-col gap-2">
             <div className="text-right">
                <div className="text-2xl font-bold text-white">{selectedCourse.units.length}</div>
                <div className="text-[10px] text-zinc-500 font-mono uppercase">Total Units</div>
             </div>
           </div>
        </div>

        <div className="grid grid-cols-1 gap-4 mb-16">
          <h3 className="text-sm font-bold text-zinc-500 uppercase tracking-widest mb-2 flex items-center gap-2">
            <Layers size={14} /> Unit Modules
          </h3>
          {selectedCourse.units.map((unit, idx) => (
            <div 
              key={idx} 
              className="group flex items-center justify-between p-6 rounded-2xl bg-[#0A0A0A] border border-white/5 hover:border-primary-500/30 transition-all hover:bg-zinc-900/30"
            >
              <div className="flex items-center gap-6">
                 <div className="w-10 h-10 rounded-full border border-zinc-800 bg-black flex items-center justify-center text-zinc-500 font-mono text-sm group-hover:border-primary-500 group-hover:text-primary-400 transition-colors">
                   {idx + 1}
                 </div>
                 <div>
                    <h4 className="font-bold text-lg text-white mb-1 group-hover:text-primary-400 transition-colors">{unit.title}</h4>
                    <p className="text-sm text-zinc-500 line-clamp-1">{unit.topics}</p>
                 </div>
              </div>
              
              <button 
                onClick={() => handleStudyUnit(unit, idx)}
                disabled={loadingUnit !== null}
                className="px-6 py-2.5 rounded-xl bg-white/5 border border-white/10 hover:bg-primary-600 hover:border-primary-500 hover:text-white transition-all text-sm font-bold flex items-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed group-hover:shadow-lg"
              >
                {loadingUnit === unit.title ? (
                  <span className="animate-pulse">Synthesizing...</span>
                ) : (
                  <>
                    Initialize <ChevronRight size={14} />
                  </>
                )}
              </button>
            </div>
          ))}
        </div>

        <div className="p-8 rounded-3xl bg-gradient-to-r from-zinc-900 to-black border border-white/10 flex items-center justify-between relative overflow-hidden group">
           <div className="absolute top-0 right-0 w-64 h-full bg-gradient-to-l from-primary-900/20 to-transparent pointer-events-none"></div>
           <div className="relative z-10 flex items-center gap-6">
              <div className="w-16 h-16 rounded-full bg-primary-600/20 border border-primary-500/50 flex items-center justify-center text-primary-400">
                 <Target size={32} />
              </div>
              <div>
                 <h3 className="text-2xl font-bold text-white mb-1">Cumulative Final Assessment</h3>
                 <p className="text-zinc-400 text-sm">50-Question Protocol covering all {selectedCourse.units.length} units.</p>
              </div>
           </div>
           <button 
             onClick={handleComprehensiveExam}
             disabled={loadingExam}
             className="relative z-10 px-8 py-4 bg-primary-600 hover:bg-primary-500 text-white font-bold rounded-xl shadow-[0_0_20px_rgba(37,99,235,0.4)] transition-all hover:scale-105 disabled:opacity-50"
           >
             {loadingExam ? 'Constructing Exam...' : 'Start Examination'}
           </button>
        </div>
      </div>
    );
  }

  return (
    <div className="py-8 animate-enter">
       <div className="text-center mb-16 space-y-4">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-blue-900/20 border border-blue-500/30 text-blue-400 text-xs font-bold uppercase tracking-widest backdrop-blur-sm">
             <Brain size={12} /> AP Nexus
          </div>
          <h1 className="text-5xl font-bold text-white tracking-tight">Advanced Placement Protocol</h1>
          <p className="text-zinc-400 max-w-xl mx-auto text-lg">Select a neural pathway to begin targeted acquisition.</p>
       </div>

       <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto px-4">
          {sortedCourses.map((course, idx) => {
             const locked = isLocked(course.id);
             
             return (
               <button 
                 key={course.id}
                 onClick={() => handleCourseSelect(course)}
                 className={`group flex flex-col items-start text-left p-6 rounded-2xl border transition-all hover:-translate-y-1 hover:shadow-2xl relative overflow-hidden h-full ${locked ? 'bg-black border-zinc-800 opacity-70' : 'bg-[#0A0A0A] border-white/5 hover:border-white/20'}`}
                 style={{ animationDelay: `${idx * 50}ms` }}
               >
                  {/* Lock Overlay */}
                  {locked && (
                      <div className="absolute inset-0 bg-black/60 backdrop-blur-[2px] flex items-center justify-center z-20 group-hover:bg-black/40 transition-colors">
                          <div className="p-3 rounded-full bg-zinc-900 border border-zinc-700 shadow-xl flex items-center gap-2 px-4">
                              <Lock size={16} className="text-zinc-500" />
                              <span className="text-xs font-bold text-zinc-400 uppercase">Locked</span>
                          </div>
                      </div>
                  )}

                  <div className={`absolute top-0 left-0 w-full h-1 bg-gradient-to-r transition-opacity duration-300 opacity-0 group-hover:opacity-100 ${
                    course.category === 'Math' ? 'from-blue-600 to-cyan-400' :
                    course.category === 'Science' ? 'from-green-600 to-emerald-400' :
                    course.category === 'History' ? 'from-orange-600 to-red-400' :
                    'from-purple-600 to-pink-400'
                  }`}></div>

                  <div className="flex justify-between w-full mb-6">
                     <div className={`p-3 rounded-xl border ${getCategoryColor(course.category)}`}>
                        <GraduationCap size={20} />
                     </div>
                     <div className="flex items-center gap-1 text-[10px] font-mono text-zinc-500 uppercase">
                        <Layers size={10} /> {course.units.length} Units
                     </div>
                  </div>

                  <h3 className="text-xl font-bold text-white mb-2 group-hover:text-white/90">{course.title}</h3>
                  <p className="text-sm text-zinc-500 leading-relaxed mb-6 line-clamp-2">{course.description}</p>
                  
                  <div className="mt-auto flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-zinc-600 group-hover:text-primary-400 transition-colors">
                     Access Module <ArrowLeft className="rotate-180" size={12} />
                  </div>
               </button>
             );
          })}
       </div>
    </div>
  );
};

export default APCenter;
