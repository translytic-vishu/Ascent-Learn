
import React, { useState, useRef } from 'react';
import { X, Youtube, Type, UploadCloud, Loader2, AlertCircle, Lock, CheckCircle, Brain, Database, FileText, ArrowUpCircle } from 'lucide-react';
import { createResource } from '../services/mockDb';
import { generateSummary, generateFlashcards, generateQuiz, synthesizeVideoContent } from '../services/geminiService';
import { Resource } from '../types';
import { validateInput, dailyUploadLimiter, getTierLimits } from '../utils/security';
import * as pdfjsLib from 'pdfjs-dist';

// Configure worker for PDF parsing
// FIXED: Use unpkg with exact version to prevent minor version mismatches (5.4.530 vs 5.4.624)
pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://unpkg.com/pdfjs-dist@5.4.530/build/pdf.worker.min.mjs';

interface UploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onUploadComplete: () => void;
  darkMode: boolean;
}

type ProcessingStep = 'idle' | 'fetching_transcript' | 'extracting' | 'synthesizing' | 'generating' | 'finalizing';

const UploadModal: React.FC<UploadModalProps> = ({ isOpen, onClose, onUploadComplete, darkMode }) => {
  const [activeTab, setActiveTab] = useState<'youtube' | 'text'>('youtube');
  const [input, setInput] = useState('');
  const [processingStep, setProcessingStep] = useState<ProcessingStep>('idle');
  const [error, setError] = useState('');
  const [dragActive, setDragActive] = useState(false);
  const [isPdfProcessing, setIsPdfProcessing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleSubmit = async () => {
    setError('');
    
    // 1. Check Limits
    const limits = getTierLimits();
    if (!dailyUploadLimiter.check(limits.dailyUploads)) {
      setError(`Daily upload limit reached for ${limits.label} Tier (${limits.dailyUploads}). Please upgrade or wait 24h.`);
      return;
    }

    // 2. Validate Content Length (Skip for URL initial check, validate later)
    if (activeTab !== 'youtube') {
        const validation = validateInput(input, 'content');
        if (!validation.valid) {
            setError(validation.error || 'Invalid input');
            return;
        }
    } else if (!input.startsWith('http')) {
        setError('Please enter a valid YouTube URL');
        return;
    }
    
    // Start Visual Sequence
    setProcessingStep(activeTab === 'youtube' ? 'fetching_transcript' : 'extracting');

    try {
      const title = activeTab === 'youtube' ? 'YouTube Video Analysis' : 'Note Analysis';
      let content = input;

      // Special YouTube Handling
      if (activeTab === 'youtube') {
          // Use Search Grounding to get "transcript"
          content = await synthesizeVideoContent(input);
          if (!content || content.length < 50) {
              throw new Error("Unable to retrieve video content. Video might be private or unavailable.");
          }
      }

      setProcessingStep('synthesizing');
      const summary = await generateSummary(content);
      
      setProcessingStep('generating');
      const [flashcards, quiz] = await Promise.all([
        generateFlashcards(content),
        generateQuiz(content)
      ]);

      setProcessingStep('finalizing');
      await new Promise(r => setTimeout(r, 1000));

      const newResource: Resource = {
        id: Date.now().toString(),
        title: title,
        type: activeTab === 'youtube' ? 'YOUTUBE' : 'TEXT',
        originalContent: content,
        summary,
        flashcards,
        quiz,
        createdAt: Date.now(),
        lastAccessed: Date.now(),
        status: 'ready',
        tags: ['New']
      };

      await createResource(newResource);
      onUploadComplete();
      onClose();
    } catch (e: any) {
      setError(e.message || 'Processing failed.');
      setProcessingStep('idle');
    }
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    } else if (e.type === "drop") {
      setDragActive(false);
      if (activeTab === 'text') {
        const files = e.dataTransfer.files;
        if (files && files.length > 0 && files[0].type === 'application/pdf') {
          processPdfFile(files[0]);
        } else {
          setError("Please drop a valid PDF file.");
        }
      }
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files.length > 0) {
       processPdfFile(files[0]);
    }
  };

  const processPdfFile = async (file: File) => {
    setIsPdfProcessing(true);
    setError('');
    try {
      const arrayBuffer = await file.arrayBuffer();
      const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
      let fullText = '';
      
      for (let i = 1; i <= pdf.numPages; i++) {
        const page = await pdf.getPage(i);
        const textContent = await page.getTextContent();
        const pageText = textContent.items.map((item: any) => item.str).join(' ');
        fullText += pageText + '\n\n';
      }

      if (!fullText.trim()) {
        throw new Error("Could not extract text. PDF might be an image.");
      }

      setInput(fullText);
    } catch (e: any) {
      console.error(e);
      setError("Failed to parse PDF: " + (e.message || "Unknown error"));
    } finally {
      setIsPdfProcessing(false);
      // Reset file input
      if (fileInputRef.current) fileInputRef.current.value = '';
    }
  };

  const isProcessing = processingStep !== 'idle';
  const limits = getTierLimits();
  const currentCount = dailyUploadLimiter.getCurrentCount();

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-md p-4 animate-in fade-in duration-200">
      <div className="w-full max-w-xl rounded-2xl border border-dark-border shadow-2xl overflow-hidden flex flex-col bg-black relative">
        <div className="absolute top-0 w-full h-1 bg-gradient-to-r from-transparent via-primary-600 to-transparent"></div>
        
        {/* Header */}
        <div className="px-6 py-5 border-b border-dark-border flex items-center justify-between bg-dark-card">
          <div>
             <h3 className="font-bold text-lg text-white flex items-center gap-2">
               {isProcessing ? 'Neural Processing Active' : 'Ingest New Content'}
               {!isProcessing && <span className="px-2 py-0.5 rounded text-[10px] bg-primary-900/30 text-primary-400 border border-primary-900/50">SECURE</span>}
             </h3>
             <p className="text-xs mt-1 text-zinc-500">
               {isProcessing ? 'Please keep this window open.' : 'AI Analysis & Embedding Generation'}
             </p>
          </div>
          {!isProcessing && (
            <button onClick={onClose} className="p-2 rounded-lg hover:bg-white/10 transition-colors text-zinc-400 hover:text-white">
              <X size={20} />
            </button>
          )}
        </div>

        {/* Content Body */}
        <div className="p-6 bg-black min-h-[350px] flex flex-col">
          {isProcessing ? (
            <div className="flex-1 flex flex-col justify-center items-center space-y-8 py-8">
              {/* Animated Brain/Loader */}
              <div className="relative">
                 <div className="w-20 h-20 rounded-full border-4 border-zinc-800 flex items-center justify-center">
                    <Brain size={32} className="text-zinc-600" />
                 </div>
                 <svg className="absolute top-0 left-0 w-20 h-20 animate-spin" viewBox="0 0 100 100">
                    <circle cx="50" cy="50" r="46" stroke="#2962FF" strokeWidth="4" fill="none" strokeDasharray="200" strokeDashoffset="50" strokeLinecap="round" />
                 </svg>
              </div>

              {/* Steps */}
              <div className="w-full max-w-sm space-y-4">
                 <ProcessingStepItem active={processingStep === 'fetching_transcript'} completed={['extracting', 'synthesizing', 'generating', 'finalizing'].includes(processingStep)} label="Acquiring Transcript Signal" icon={<Youtube size={16} />} />
                 <ProcessingStepItem active={processingStep === 'extracting'} completed={['synthesizing', 'generating', 'finalizing'].includes(processingStep)} label="Parsing Raw Data" icon={<FileText size={16} />} />
                 <ProcessingStepItem active={processingStep === 'synthesizing'} completed={['generating', 'finalizing'].includes(processingStep)} label="Synthesizing Knowledge Graph" icon={<Brain size={16} />} />
                 <ProcessingStepItem active={processingStep === 'generating'} completed={['finalizing'].includes(processingStep)} label="Generating Active Recall Assets" icon={<Database size={16} />} />
                 <ProcessingStepItem active={processingStep === 'finalizing'} completed={false} label="Finalizing Secure Vault" icon={<Lock size={16} />} />
              </div>
            </div>
          ) : (
            <>
              {/* Tabs */}
              <div className="flex gap-3 mb-6">
                <button 
                  onClick={() => setActiveTab('youtube')}
                  className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl text-sm font-bold transition-all duration-300 border ${
                    activeTab === 'youtube' 
                      ? 'bg-primary-600 border-primary-500 text-white shadow-[0_0_15px_rgba(41,98,255,0.4)]' 
                      : 'bg-zinc-900 border-zinc-800 hover:bg-zinc-800 text-zinc-500'
                  }`}
                >
                  <Youtube size={18} /> YouTube
                </button>
                <button 
                  onClick={() => setActiveTab('text')}
                  className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl text-sm font-bold transition-all duration-300 border ${
                    activeTab === 'text' 
                      ? 'bg-primary-600 border-primary-500 text-white shadow-[0_0_15px_rgba(41,98,255,0.4)]' 
                      : 'bg-zinc-900 border-zinc-800 hover:bg-zinc-800 text-zinc-500'
                  }`}
                >
                  <Type size={18} /> Text / PDF
                </button>
              </div>

              {/* Input Area */}
              {activeTab === 'youtube' ? (
                <div className="space-y-4 flex-1">
                   <div className="flex justify-between items-end">
                      <label className="block text-xs font-mono text-zinc-500 uppercase">
                        Video Source
                      </label>
                      <span className="text-[10px] font-bold text-primary-400 uppercase">
                         Automated Transcript Fetching
                      </span>
                   </div>
                   <textarea 
                      value={input}
                      onChange={(e) => setInput(e.target.value)}
                      placeholder="Paste YouTube URL here..."
                      className="w-full h-full min-h-[200px] p-4 rounded-xl border border-zinc-800 bg-zinc-900/50 text-white outline-none resize-none transition-all placeholder:text-zinc-700 focus:border-primary-500 focus:bg-zinc-900 focus:shadow-[0_0_20px_rgba(41,98,255,0.1)] font-mono text-sm"
                   />
                </div>
              ) : (
                 <div 
                   className={`flex-1 relative flex flex-col rounded-xl border-2 border-dashed transition-all cursor-pointer ${dragActive ? 'border-primary-500 bg-primary-900/10' : 'border-zinc-800 bg-zinc-900/30 hover:border-zinc-700'}`}
                   onDragEnter={handleDrag}
                   onDragLeave={handleDrag}
                   onDragOver={handleDrag}
                   onDrop={handleDrag}
                   onClick={() => !input && fileInputRef.current?.click()}
                 >
                   <input 
                     type="file" 
                     ref={fileInputRef} 
                     className="hidden" 
                     accept=".pdf" 
                     onChange={handleFileSelect}
                   />
                   
                   <textarea 
                      value={input}
                      onChange={(e) => setInput(e.target.value)}
                      onClick={(e) => e.stopPropagation()} // Allow editing without triggering upload again
                      className={`w-full h-full p-6 bg-transparent text-white outline-none resize-none placeholder:text-transparent z-10 ${isPdfProcessing ? 'opacity-50' : ''}`}
                   />
                   
                   {!input && !isPdfProcessing && (
                     <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none p-6 text-center">
                        <div className="w-16 h-16 rounded-full bg-zinc-900 border border-zinc-700 flex items-center justify-center mb-4">
                           <UploadCloud size={24} className="text-zinc-400" />
                        </div>
                        <h4 className="text-zinc-300 font-bold mb-1">Click to Upload PDF or Drag File</h4>
                        <p className="text-zinc-500 text-xs max-w-xs">Supported formats: PDF. Text extraction happens securely in your browser.</p>
                     </div>
                   )}

                   {isPdfProcessing && (
                      <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/60 backdrop-blur-sm z-20">
                          <Loader2 size={32} className="text-primary-500 animate-spin mb-3" />
                          <span className="text-white font-bold text-sm">Extracting PDF Text...</span>
                      </div>
                   )}
                </div>
              )}

              {error && (
                <div className="mt-4 p-3 rounded-lg bg-red-900/10 border border-red-900/30 text-red-400 text-xs flex items-center gap-2 animate-in fade-in slide-in-from-top-2">
                  <AlertCircle size={14} />
                  {error}
                </div>
              )}
            </>
          )}
        </div>

        {/* Footer */}
        {!isProcessing && (
          <div className="px-6 py-5 border-t border-dark-border flex justify-between items-center bg-dark-card">
            <div className="text-[10px] text-zinc-600 font-mono uppercase">
               Daily Quota: {currentCount} / {limits.dailyUploads}
            </div>
            <div className="flex gap-3">
              <button 
                onClick={onClose}
                className="px-5 py-2.5 rounded-xl text-sm font-medium transition-colors text-zinc-400 hover:text-white hover:bg-white/5"
              >
                Abort
              </button>
              <button 
                onClick={handleSubmit}
                className="px-6 py-2.5 rounded-xl bg-primary-600 hover:bg-primary-500 text-white text-sm font-bold flex items-center gap-2 shadow-[0_0_15px_rgba(41,98,255,0.4)] transition-all hover:shadow-[0_0_25px_rgba(41,98,255,0.6)]"
              >
                <ArrowUpCircle size={18} /> Initialize Sequence
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

const ProcessingStepItem = ({ active, completed, label, icon }: any) => (
  <div className={`flex items-center gap-3 transition-all duration-300 ${active || completed ? 'opacity-100' : 'opacity-40'}`}>
    <div className={`w-8 h-8 rounded-full flex items-center justify-center border transition-colors ${
      completed ? 'bg-primary-600 border-primary-600 text-white' : 
      active ? 'bg-primary-900/20 border-primary-500 text-primary-400 animate-pulse' : 
      'bg-zinc-900 border-zinc-800 text-zinc-600'
    }`}>
      {completed ? <CheckCircle size={14} /> : icon}
    </div>
    <span className={`text-sm font-medium ${active ? 'text-white' : 'text-zinc-400'}`}>{label}</span>
  </div>
);

export default UploadModal;
