
import React, { useEffect, useState } from 'react';
import { Clock, BookOpen, Brain, Flame, FileText, Youtube, Mic, ArrowRight, Plus, Activity, Search, Filter, Terminal, Zap, Layers, Play, Pause, RotateCcw, CheckSquare, Sparkles, Target, MoreHorizontal, Check, X, Shield, ChevronRight, Trash2 } from 'lucide-react';
import { Resource, UserStats, StudyTask } from '../types';
import { getUserStats } from '../services/mockDb';

interface DashboardProps {
  darkMode: boolean;
  resources: Resource[];
  onResourceClick: (id: string) => void;
  onUploadClick: () => void;
  onExamClick: () => void;
  // Todo Props
  todoTasks: StudyTask[];
  onAddTodo: (text: string) => void;
  onToggleTodo: (id: string) => void;
  onDeleteTodo: (id: string) => void;
}

const Dashboard: React.FC<DashboardProps> = ({ 
  darkMode, 
  resources, 
  onResourceClick, 
  onUploadClick, 
  onExamClick,
  todoTasks,
  onAddTodo,
  onToggleTodo,
  onDeleteTodo
}) => {
  const [stats, setStats] = useState<UserStats | null>(null);
  const [greeting, setGreeting] = useState('');
  const [currentTime, setCurrentTime] = useState(new Date());
  
  // Dynamic Velocity Calculation
  // Goal: 1 hour (3600s)
  const focusTime = stats?.hoursLearned ? stats.hoursLearned * 3600 : 0;
  const velocityPercentage = Math.min(100, Math.round((focusTime / 3600) * 100));
  const strokeDashoffset = 163.36 - (163.36 * (velocityPercentage / 100));

  useEffect(() => {
    getUserStats().then(setStats);
    
    // Dynamic Greeting
    const hour = new Date().getHours();
    if (hour < 12) setGreeting('Good Morning');
    else if (hour < 18) setGreeting('Good Afternoon');
    else setGreeting('Good Evening');

    // Live Clock
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, [resources]); // Re-fetch when resources change

  return (
    <div className="space-y-12 pb-20 animate-enter">
      
      {/* HUD Header */}
      <div className="flex flex-col lg:flex-row lg:items-end justify-between gap-8">
        <div className="space-y-2 relative">
           <h1 className="text-5xl md:text-6xl font-bold text-white tracking-tight flex flex-col md:flex-row md:items-center gap-2 md:gap-4">
            <span>{greeting},</span>
            <span className="text-zinc-500">Scholar.</span>
          </h1>
          <div className="flex items-center gap-4 text-sm font-mono text-zinc-500 mt-2">
            <span className="px-2 py-0.5 rounded bg-green-500/10 text-green-500 border border-green-500/20 flex items-center gap-2">
               <span className="w-1.5 h-1.5 rounded-full bg-green-500 animate-pulse"></span>
               SYSTEM ONLINE
            </span>
            <span className="text-zinc-700">|</span>
            <span>{currentTime.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'})}</span>
          </div>
        </div>
        
        {/* Daily Focus HUD */}
        <div className="group relative overflow-hidden rounded-2xl bg-[#0A0A0A] border border-white/5 p-1 transition-all hover:border-white/10">
           <div className="flex items-center gap-6 px-6 py-4 bg-black/50 backdrop-blur-sm rounded-xl">
              <div className="relative w-14 h-14 flex items-center justify-center">
                <svg className="w-full h-full transform -rotate-90" viewBox="0 0 60 60">
                  {/* Background Circle */}
                  <circle cx="30" cy="30" r="26" stroke="#1F1F1F" strokeWidth="4" fill="none" />
                  {/* Progress Circle: 2 * PI * 26 ≈ 163.36 */}
                  <circle 
                    cx="30" cy="30" r="26" 
                    stroke="#2563EB" 
                    strokeWidth="4" 
                    fill="none" 
                    strokeDasharray="163.36" 
                    strokeDashoffset={strokeDashoffset} 
                    strokeLinecap="round" 
                    className="transition-all duration-1000 ease-out" 
                  />
                </svg>
                <Zap size={20} className={`absolute ${velocityPercentage === 100 ? 'text-yellow-400' : 'text-white'} drop-shadow-[0_0_8px_rgba(37,99,235,0.8)]`} />
              </div>
              
              <div className="space-y-0.5">
                <div className="text-[10px] text-primary-400 uppercase font-bold tracking-widest flex items-center gap-2">
                  Daily Velocity
                </div>
                <div className="text-2xl font-bold text-white tracking-tight">{velocityPercentage}%</div>
                <div className="text-xs text-zinc-500 font-medium">{Math.round(focusTime/60)}m / 60m Target</div>
              </div>
           </div>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 animate-enter stagger-1">
        <StatCard 
          icon={<Flame size={20} />} 
          label="Current Streak" 
          value={stats?.streak || 0} 
          unit="Days"
          trend="+1"
          color="orange"
        />
        <StatCard 
          icon={<Brain size={20} />} 
          label="Knowledge Base" 
          value={stats?.cardsLearned || 0} 
          unit="Concepts"
          trend="+12%"
          color="blue"
        />
        <StatCard 
          icon={<Clock size={20} />} 
          label="Deep Focus" 
          value={stats?.hoursLearned || 0} 
          unit="Hours"
          trend="Total"
          color="cyan"
        />
        <StatCard 
          icon={<Layers size={20} />} 
          label="Retention" 
          value={stats?.quizScoreAvg || 0} 
          unit="%"
          trend="Avg"
          color="purple"
        />
      </div>

      {/* Command Deck */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 animate-enter stagger-2">
         
         {/* Ingestion Column */}
         <div className="lg:col-span-2 space-y-6">
            <h2 className="text-xs font-bold uppercase tracking-widest text-zinc-500 pl-1 flex items-center gap-2">
              <Terminal size={12} /> Ingestion Protocols
            </h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 h-[320px]">
              <ActionButton icon={<FileText size={28} />} label="PDF Upload" sub="Document Parse" onClick={onUploadClick} delay={0} color="blue" />
              <ActionButton icon={<Target size={28} />} label="Exam Mode" sub="Generate Quiz" onClick={onExamClick} delay={100} color="red" />
              <ActionButton icon={<Youtube size={28} />} label="Video Sync" sub="Transcript API" onClick={onUploadClick} delay={200} color="orange" />
              <ActionButton icon={<Mic size={28} />} label="Audio Log" sub="Voice to Text" onClick={onUploadClick} delay={300} color="green" />
            </div>

            <div className="mt-8">
               <h2 className="text-xs font-bold uppercase tracking-widest text-zinc-500 pl-1 mb-4 flex items-center gap-2">
                 <Activity size={12} /> Recent Operations
               </h2>
               <div className="space-y-2">
                  {resources.slice(0, 3).map((res) => (
                    <div 
                      key={res.id} 
                      onClick={() => onResourceClick(res.id)}
                      className="group flex items-center justify-between p-4 rounded-xl border border-white/5 bg-[#0A0A0A] hover:border-white/10 hover:bg-zinc-900/50 transition-all cursor-pointer"
                    >
                       <div className="flex items-center gap-4">
                          <div className="w-10 h-10 rounded-lg bg-zinc-900 flex items-center justify-center border border-white/5 group-hover:border-primary-500/30 transition-colors">
                             <FileText size={18} className="text-zinc-400 group-hover:text-primary-400" />
                          </div>
                          <div>
                             <h4 className="font-bold text-sm text-white group-hover:text-primary-400 transition-colors">{res.title}</h4>
                             <p className="text-xs text-zinc-500">{new Date(res.createdAt).toLocaleDateString()}</p>
                          </div>
                       </div>
                       <ChevronRight size={16} className="text-zinc-600 group-hover:text-white group-hover:translate-x-1 transition-all" />
                    </div>
                  ))}
                  {resources.length === 0 && (
                    <div className="p-8 text-center text-zinc-500 border border-dashed border-zinc-900 rounded-xl">
                      No recent operations. Initialize a new protocol.
                    </div>
                  )}
               </div>
            </div>
         </div>

         {/* To-Do List Widget */}
         <div className="space-y-6">
            <h2 className="text-xs font-bold uppercase tracking-widest text-zinc-500 pl-1 flex items-center gap-2">
              <CheckSquare size={12} /> Priority Queue
            </h2>
            <div className="h-full min-h-[400px] bg-[#0A0A0A] rounded-2xl border border-white/5 p-6 flex flex-col relative overflow-hidden">
               {/* Decorative Gradient */}
               <div className="absolute top-0 right-0 w-32 h-32 bg-primary-900/10 blur-[50px] rounded-full pointer-events-none"></div>

               <TodoWidget 
                 tasks={todoTasks} 
                 onAdd={onAddTodo} 
                 onToggle={onToggleTodo} 
                 onDelete={onDeleteTodo} 
               />
            </div>
         </div>
      </div>
    </div>
  );
};

const StatCard = ({ icon, label, value, unit, trend, color }: any) => {
  const colors: any = {
    blue: "text-blue-400 bg-blue-500/10 border-blue-500/20",
    orange: "text-orange-400 bg-orange-500/10 border-orange-500/20",
    cyan: "text-cyan-400 bg-cyan-500/10 border-cyan-500/20",
    purple: "text-purple-400 bg-purple-500/10 border-purple-500/20"
  };

  return (
    <div className="bg-[#0A0A0A] border border-white/5 p-6 rounded-2xl hover:border-white/10 transition-colors group">
      <div className="flex justify-between items-start mb-4">
        <div className={`p-2.5 rounded-xl border ${colors[color]} transition-transform group-hover:scale-110`}>
          {icon}
        </div>
        <span className="text-[10px] font-bold bg-zinc-900 text-zinc-400 px-2 py-1 rounded-full border border-white/5">
          {trend}
        </span>
      </div>
      <div>
        <div className="text-3xl font-bold text-white mb-1 tracking-tight">{value} <span className="text-sm font-normal text-zinc-500">{unit}</span></div>
        <div className="text-xs font-medium text-zinc-500 uppercase tracking-wide">{label}</div>
      </div>
    </div>
  );
};

const ActionButton = ({ icon, label, sub, onClick, delay, color }: any) => {
  const colors: any = {
    blue: "group-hover:border-blue-500/50 group-hover:shadow-[0_0_30px_rgba(59,130,246,0.2)]",
    red: "group-hover:border-red-500/50 group-hover:shadow-[0_0_30px_rgba(239,68,68,0.2)]",
    orange: "group-hover:border-orange-500/50 group-hover:shadow-[0_0_30px_rgba(249,115,22,0.2)]",
    green: "group-hover:border-green-500/50 group-hover:shadow-[0_0_30px_rgba(34,197,94,0.2)]",
  };

  return (
    <button 
      onClick={onClick}
      className={`h-full flex flex-col items-center justify-center gap-4 bg-[#0A0A0A] border border-white/5 rounded-2xl transition-all duration-300 hover:-translate-y-1 group animate-enter ${colors[color]}`}
      style={{ animationDelay: `${delay}ms` }}
    >
      <div className="p-4 rounded-full bg-zinc-900/50 group-hover:bg-white/10 transition-colors">
        {React.cloneElement(icon, { className: "text-zinc-400 group-hover:text-white transition-colors" })}
      </div>
      <div className="text-center">
        <div className="font-bold text-white mb-1 group-hover:text-primary-400 transition-colors">{label}</div>
        <div className="text-[10px] font-mono text-zinc-500 uppercase tracking-widest">{sub}</div>
      </div>
    </button>
  );
};

const TodoWidget = ({ tasks, onAdd, onToggle, onDelete }: { 
  tasks: StudyTask[], 
  onAdd: (text: string) => void, 
  onToggle: (id: string) => void, 
  onDelete: (id: string) => void 
}) => {
  const [input, setInput] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim()) return;
    onAdd(input);
    setInput('');
  };

  return (
    <div className="flex flex-col h-full">
      <form onSubmit={handleSubmit} className="relative mb-6">
        <input 
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Add operational task..." 
          className="w-full bg-zinc-900/50 border border-white/5 rounded-xl px-4 py-3 pr-10 text-sm text-white placeholder:text-zinc-600 focus:outline-none focus:border-primary-500/50 focus:bg-zinc-900 transition-all"
        />
        <button 
          type="submit"
          className="absolute right-2 top-1/2 -translate-y-1/2 p-1.5 bg-white/5 hover:bg-white/20 rounded-lg text-zinc-400 hover:text-white transition-colors"
        >
          <Plus size={14} />
        </button>
      </form>

      <div className="flex-1 overflow-y-auto space-y-2 pr-2 custom-scrollbar">
        {tasks.length === 0 && (
          <div className="text-center py-10 text-zinc-600 text-xs">
            Queue empty. Awaiting directives.
          </div>
        )}
        {tasks.map((task) => (
          <div 
            key={task.id} 
            className="group flex items-center gap-3 p-3 rounded-lg bg-zinc-900/30 hover:bg-zinc-900 border border-transparent hover:border-white/5 transition-all"
          >
            <button 
              onClick={() => onToggle(task.id)}
              className={`w-5 h-5 rounded border flex items-center justify-center transition-colors ${
                task.completed ? 'bg-primary-600 border-primary-600 text-white' : 'border-zinc-700 hover:border-primary-500'
              }`}
            >
              {task.completed && <Check size={12} />}
            </button>
            <span className={`flex-1 text-sm truncate ${task.completed ? 'text-zinc-600 line-through' : 'text-zinc-300'}`}>
              {task.text}
            </span>
            <button 
              onClick={() => onDelete(task.id)}
              className="opacity-0 group-hover:opacity-100 p-1.5 text-zinc-600 hover:text-red-400 transition-all"
            >
              <Trash2 size={14} />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default Dashboard;
