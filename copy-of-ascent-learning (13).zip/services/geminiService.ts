
import { GoogleGenAI, Type } from "@google/genai";
import { Flashcard, QuizQuestion } from "../types";
import { generationRateLimiter, chatSpamLimiter, dailyChatLimiter, getTierLimits } from "../utils/security";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

// Primary model as per system preference
const MODEL_PRIMARY = 'gemini-3-flash-preview';
// Fallback model for high-traffic scenarios
const MODEL_FALLBACK = 'gemini-2.0-flash'; 

// --- INTELLIGENT CACHING SYSTEM ---
const responseCache = new Map<string, any>();

const getCacheKey = (type: string, content: string) => {
  let hash = 0;
  if (content.length === 0) return type;
  for (let i = 0; i < content.length; i++) {
    hash = ((hash << 5) - hash) + content.charCodeAt(i);
    hash |= 0; 
  }
  return `${type}_${hash}`;
};

// HELPER: Clean JSON output from AI (Removes markdown backticks)
const parseAIResponse = (text: string | undefined): any => {
  if (!text) return [];
  try {
    // Remove ```json and ``` wrapping if present
    const cleanText = text.replace(/```json/g, '').replace(/```/g, '').trim();
    return JSON.parse(cleanText);
  } catch (e) {
    console.error("JSON Parse Error:", e);
    // Return empty array on failure to prevent app crash
    return [];
  }
};

const smartGenerate = async (
  apiCall: (model: string) => Promise<any>, 
  cacheKey?: string
) => {
  if (cacheKey && responseCache.has(cacheKey)) {
    console.log("⚡ Neural Cache Hit");
    return responseCache.get(cacheKey);
  }

  // Double check key existence before calling
  if (!process.env.API_KEY) {
    throw new Error("API Key Invalid. Please check your Netlify Environment Variables.");
  }

  let attempts = 0;
  const maxAttempts = 3;
  let currentModel = MODEL_PRIMARY;

  while (attempts < maxAttempts) {
    try {
      // Only check generation limiter if we aren't in a retry loop to avoid double counting
      if (attempts === 0 && !generationRateLimiter.check()) {
          throw new Error("Local System Traffic High. Please wait 10 seconds.");
      }

      const result = await apiCall(currentModel);
      
      if (cacheKey) responseCache.set(cacheKey, result);
      return result;

    } catch (error: any) {
      attempts++;
      console.warn(`Attempt ${attempts} failed with ${currentModel}:`, error.message);
      
      const isRateLimit = error.message.includes("429") || error.message.includes("quota") || error.message.includes("Too Many Requests");
      const isModelError = error.message.includes("not found") || error.message.includes("404");
      const isKeyError = error.message.includes("API key not valid") || error.message.includes("400") || error.message.includes("API_KEY_INVALID");

      if (isKeyError) {
         throw new Error("Access Denied: The provided API Key is invalid or expired.");
      }

      // If primary model fails with 404 (not found) or 429 (rate limit), switch to fallback immediately
      if ((isModelError || isRateLimit) && currentModel === MODEL_PRIMARY) {
          console.log(`Switching to fallback model: ${MODEL_FALLBACK}`);
          currentModel = MODEL_FALLBACK;
          // Short delay before fallback retry
          await new Promise(r => setTimeout(r, 1000));
          continue;
      }

      if (isRateLimit) {
         if (attempts === maxAttempts) {
            throw new Error("System Traffic High (API Quota). Please try again in 1 minute.");
         }
         // Exponential backoff
         const delay = (2000 * Math.pow(2, attempts - 1)) + (Math.random() * 1000);
         await new Promise(r => setTimeout(r, delay));
         continue;
      }
      
      if (attempts === maxAttempts) throw error;
      
      const delay = (1000 * Math.pow(2, attempts - 1)) + (Math.random() * 1000);
      await new Promise(r => setTimeout(r, delay));
    }
  }
};

const isShortOrUrl = (text: string) => text.trim().length < 300 || text.startsWith('http');

export const synthesizeVideoContent = async (url: string): Promise<string> => {
  return smartGenerate(async (model) => {
    const response = await ai.models.generateContent({
      model: model,
      contents: `Target URL: ${url}. Perform a deep search. OUTPUT: Comprehensive textual transcript/summary of this video content. Include all key facts, numbers, and arguments.`,
      config: { tools: [{googleSearch: {}}] }
    });
    return response.text || "Could not retrieve video content.";
  }, getCacheKey('video', url));
};

export const generateSummary = async (text: string): Promise<string> => {
  if (!text) return "";
  
  return smartGenerate(async (model) => {
    const isTopic = isShortOrUrl(text);
    const contextPrompt = isTopic 
      ? `User Input: "${text}". Treat as a TOPIC. Assume expert knowledge.` 
      : `INPUT TEXT: ${text.substring(0, 200000)}`;

    const response = await ai.models.generateContent({
      model: model,
      contents: `You are Ascent AI, an elite educational architect.
      
      OBJECTIVE: Construct a high-fidelity "Mastery Protocol" (Summary) from the input.
      
      FORMATTING:
      - Use ONLY raw HTML tags: <h2>, <p>, <ul>, <li>, <strong>.
      - NO Markdown blocks.
      - TONE: Professional, concise, yet extremely dense with information.
      - VOCABULARY: Accessible but precise (High School/College level).
      
      STRUCTURE:
      - <h2>Executive Synthesis</h2>: High-level abstract.
      - <h2>Core Mechanics</h2>: Detailed explanation of mechanisms/concepts.
      - <h2>Critical Data Points</h2>: <ul> list of facts/stats.
      - <h2>Applied Theory</h2>: Real-world application.
      - <h2>Deep Dive Analysis</h2>: Extensive section covering nuances.
      
      ${contextPrompt}`,
    });
    return response.text || "<h2>Error: Neural Synthesis Failed</h2>";
  }, getCacheKey('summary', text));
};

export const generateAPSummary = async (text: string): Promise<string> => {
  return smartGenerate(async (model) => {
    const response = await ai.models.generateContent({
      model: model,
      contents: `Context: ${text}. OBJECTIVE: Generate a "Comprehensive AP Unit Mastery Protocol".
      
      INSTRUCTIONS:
      - Output must be comprehensive (1000+ words equivalent depth).
      - Use raw HTML (h2, p, ul, li, strong).
      - Focus on "High Yield" AP exam content.
      
      STRUCTURE:
      - <h2>Unit Overview</h2>
      - <h2>Core Concepts Deep Dive</h2>
      - <h2>Essential Vocabulary</h2>
      - <h2>Key Relationships</h2>
      - <h2>Exam Strategy</h2>`,
    });
    return response.text || "<h2>Error generating review sheet.</h2>";
  }, getCacheKey('ap_summary', text));
};

export const generateAPQuiz = async (text: string, count: number): Promise<QuizQuestion[]> => {
  return smartGenerate(async (model) => {
    const response = await ai.models.generateContent({
      model: model,
      contents: `Context: ${text}. Create exactly ${count} AP-Level multiple-choice questions.
      Difficulty: Hard (College Board Standard). STRICT ADHERENCE to official AP exam phrasing, distractor logic, and stimulus-based questioning. Avoid simple recall.
      OUTPUT: JSON Array.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              question: { type: Type.STRING },
              options: { type: Type.ARRAY, items: { type: Type.STRING } },
              correctAnswer: { type: Type.INTEGER },
              explanation: { type: Type.STRING }
            },
            required: ["question", "options", "correctAnswer", "explanation"]
          }
        }
      }
    });
    const json = parseAIResponse(response.text);
    return json.map((q: any, index: number) => ({ id: `ap-qz-${Date.now()}-${index}`, ...q }));
  }, getCacheKey(`ap_quiz_${count}`, text));
};

export const generateSATLesson = async (skillContext: string): Promise<string> => {
  return smartGenerate(async (model) => {
    const response = await ai.models.generateContent({
      model: model,
      contents: `Create a SAT Mastery Guide for: "${skillContext}".
      Output HTML. Keep it simple, actionable, and strategy-focused.
      Include: Concept Breakdown, Key Formulas, Step-by-Step Strategy, Common Traps.`,
    });
    return response.text || "<h2>Error generating lesson.</h2>";
  }, getCacheKey('sat_lesson', skillContext));
};

export const generateSATQuestions = async (count: number, type: 'MATH' | 'READING_WRITING', context?: string): Promise<QuizQuestion[]> => {
  const cacheStr = `sat_${type}_${count}_${context || 'gen'}`;
  
  return smartGenerate(async (model) => {
    const typePrompt = type === 'MATH' ? "SAT Math" : "SAT Reading & Writing";
    const additionalContext = context ? `FOCUS SKILL: ${context}` : "Generate a diverse set.";

    const response = await ai.models.generateContent({
      model: model,
      contents: `Create ${count} ${typePrompt} questions. ${additionalContext}.
      DIFFICULTY: Hard (Official SAT Standard). 
      MATH: Mirror exact phrasing of official Bluebook questions. Realistic values.
      READING: Short passages (25-100 words). Mimic the tone, density, and structure of official SAT passages perfectly.
      OUTPUT: JSON Array.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              question: { type: Type.STRING },
              options: { type: Type.ARRAY, items: { type: Type.STRING } },
              correctAnswer: { type: Type.INTEGER },
              explanation: { type: Type.STRING }
            },
            required: ["question", "options", "correctAnswer", "explanation"]
          }
        }
      }
    });
    const json = parseAIResponse(response.text);
    return json.map((q: any, index: number) => ({ id: `sat-${type}-${Date.now()}-${index}`, ...q }));
  }, getCacheKey(cacheStr, "sat"));
};

export const generateFullSATExam = async (): Promise<{math: QuizQuestion[], rw: QuizQuestion[]}> => {
  // Execute sequentially to avoid rate limits
  const math = await generateSATQuestions(22, 'MATH');
  const rw = await generateSATQuestions(27, 'READING_WRITING');
  return { math, rw };
};

export const generateFlashcards = async (text: string): Promise<Flashcard[]> => {
  return smartGenerate(async (model) => {
    const isTopic = isShortOrUrl(text);
    const contextPrompt = isTopic ? `Topic: "${text}"` : `Text: ${text.substring(0, 200000)}`;

    const response = await ai.models.generateContent({
      model: model,
      contents: `Extract 8-12 high-yield concepts into flashcards. Focus on hard facts, numbers, and causal links. ${contextPrompt}`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              front: { type: Type.STRING },
              back: { type: Type.STRING }
            },
            required: ["front", "back"]
          }
        }
      }
    });
    const json = parseAIResponse(response.text);
    return json.map((card: any, index: number) => ({ id: `fc-${Date.now()}-${index}`, front: card.front, back: card.back, status: 'new' }));
  }, getCacheKey('flashcards', text));
};

export const generateQuiz = async (text: string, count: number = 5): Promise<QuizQuestion[]> => {
  return smartGenerate(async (model) => {
    const isTopic = isShortOrUrl(text);
    const contextPrompt = isTopic ? `Topic: "${text}"` : `Text: ${text.substring(0, 200000)}`;

    const response = await ai.models.generateContent({
      model: model,
      contents: `Design a ${count}-question quiz. Difficulty: University Level. ${contextPrompt}`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              question: { type: Type.STRING },
              options: { type: Type.ARRAY, items: { type: Type.STRING } },
              correctAnswer: { type: Type.INTEGER },
              explanation: { type: Type.STRING }
            },
            required: ["question", "options", "correctAnswer", "explanation"]
          }
        }
      }
    });
    const json = parseAIResponse(response.text);
    return json.map((q: any, index: number) => ({ id: `qz-${Date.now()}-${index}`, ...q }));
  }, getCacheKey(`quiz_${count}`, text));
};

export const generateMultiSourceQuiz = async (aggregatedText: string, count: number): Promise<QuizQuestion[]> => {
  return smartGenerate(async (model) => {
    const response = await ai.models.generateContent({
      model: model,
      contents: `Design a comprehensive exam (${count} Qs) based on multiple sources. Difficulty: Professional. Source Text: ${aggregatedText.substring(0, 200000)}`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              question: { type: Type.STRING },
              options: { type: Type.ARRAY, items: { type: Type.STRING } },
              correctAnswer: { type: Type.INTEGER },
              explanation: { type: Type.STRING }
            },
            required: ["question", "options", "correctAnswer", "explanation"]
          }
        }
      }
    });
    const json = parseAIResponse(response.text);
    return json.map((q: any, index: number) => ({ id: `qz-exam-${Date.now()}-${index}`, ...q }));
  });
};

export const chatWithResource = async (query: string, context: string, history: {role: string, content: string}[]) => {
  if (!chatSpamLimiter.check()) throw new Error("Chatting too fast.");
  const limits = getTierLimits();
  if (!dailyChatLimiter.check(limits.dailyChats)) throw new Error("Daily chat quota reached.");

  const isTopic = isShortOrUrl(context);
  const sysContext = isTopic 
     ? `TOPIC CONTEXT: ${context}`
     : `SYSTEM CONTEXT: ${context.substring(0, 200000)}`;

  const chat = ai.chats.create({
    model: MODEL_PRIMARY, // Chat usually handles fallback internally or we keep simple
    history: [
      { role: 'user', parts: [{ text: `${sysContext}\n\nINSTRUCTION: Answer strictly based on context. Be concise.` }] },
      { role: 'model', parts: [{ text: "Context received." }] },
      ...history.map(h => ({ role: h.role, parts: [{ text: h.content }] }))
    ],
  });

  return await chat.sendMessageStream({ message: query });
};

export const generateStudyPlan = async (goal: string): Promise<string[]> => {
  return smartGenerate(async (model) => {
     const response = await ai.models.generateContent({
      model: model,
      contents: `Generate 5 actionable study steps for: "${goal}". Simple vocabulary. Max 10 words each. Return simple list items only.`,
    });
    return (response.text || "").split('\n').filter(l => l.trim().length > 0).map(l => l.replace(/^[\d\-\.\*]+\s*/, '')).slice(0, 5);
  }, getCacheKey('plan', goal));
};
